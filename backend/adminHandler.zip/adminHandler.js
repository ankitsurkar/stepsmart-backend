// Lambda: lms-admin
// Trigger: ALL /admin/*
// Auth:    Cognito Authorizer (JWT required) + admin group check (Layer 2 security)
//
// One Lambda handles all admin routes. This keeps admin logic co-located and minimises
// cold-start surface area.
//
// Admin group check is performed in the Lambda (not only in the React UI).
// A non-admin JWT cannot contain 'admins' in cognito:groups because Cognito signs the token.
// Even if someone bypasses the React AdminRoute guard, this Lambda returns 403.
//
// Routes handled:
//   GET    /admin/students                               → list all Cognito users
//   POST   /admin/students                               → create student in Cognito
//   GET    /admin/courses/{courseId}/weeks               → all weeks (including hidden)
//   POST   /admin/courses/{courseId}/weeks               → create week
//   PATCH  /admin/courses/{courseId}/weeks/{weekId}      → update week (visibility, content)
//   DELETE /admin/courses/{courseId}/weeks/{weekId}      → delete week
//   GET    /admin/courses/{courseId}/progress            → all student progress for a course

const { SSMClient, GetParameterCommand } = require('@aws-sdk/client-ssm');
const ssm = new SSMClient({ region: process.env.AWS_REGION || 'eu-north-1' });

let cachedSupaUrl = null;
let cachedSupaKey = null;

async function getSupabaseCreds() {
  if (cachedSupaUrl && cachedSupaKey) {
    return { url: cachedSupaUrl, key: cachedSupaKey };
  }
  try {
    const [urlRes, keyRes] = await Promise.all([
      ssm.send(new GetParameterCommand({ Name: '/stepsmart/supabase/url' })),
      ssm.send(new GetParameterCommand({ Name: '/stepsmart/supabase/service-role-key', WithDecryption: true })),
    ]);
    cachedSupaUrl = urlRes.Parameter.Value;
    cachedSupaKey = keyRes.Parameter.Value;
    return { url: cachedSupaUrl, key: cachedSupaKey };
  } catch (err) {
    console.error('Error fetching Supabase credentials from SSM Parameter Store:', err);
    return null;
  }
}

const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const {
  DynamoDBDocumentClient,
  QueryCommand,
  GetCommand,
  PutCommand,
  UpdateCommand,
  DeleteCommand,
  ScanCommand,
} = require('@aws-sdk/lib-dynamodb');

const {
  CognitoIdentityProviderClient,
  ListUsersCommand,
  AdminCreateUserCommand,
  AdminAddUserToGroupCommand,
  AdminGetUserCommand,
} = require('@aws-sdk/client-cognito-identity-provider');

const { randomUUID } = require('crypto');

const ddbClient = new DynamoDBClient({ region: process.env.AWS_REGION || 'eu-north-1' });
const ddb = DynamoDBDocumentClient.from(ddbClient, {
  marshallOptions: { convertEmptyValues: true },
});
const cognito = new CognitoIdentityProviderClient({ region: process.env.AWS_REGION || 'eu-north-1' });

const COURSES_TABLE = process.env.COURSES_TABLE || 'lms-courses';
const PROGRESS_TABLE = process.env.PROGRESS_TABLE || 'lms-progress';
const ENROLLMENTS_TABLE = process.env.ENROLLMENTS_TABLE || 'lms-enrollments';
const USER_POOL_ID = process.env.USER_POOL_ID || '';
const FRONTEND_URL = process.env.FRONTEND_URL || 'https://stepsmart.net';
const SUPPLEMENTAL_SK = 'SUPPLEMENTAL#GLOBAL';

function deriveUserPoolId(event) {
  if (process.env.USER_POOL_ID) return process.env.USER_POOL_ID;
  const issuer = event?.requestContext?.authorizer?.claims?.iss;
  return issuer ? issuer.split('/').pop() : '';
}

let currentOrigin = FRONTEND_URL;

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': currentOrigin,
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PATCH,DELETE,OPTIONS',
  };
}

function res(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', ...corsHeaders() },
    body: JSON.stringify(body),
  };
}

async function signRecordedSessions(sessions) {
  if (!Array.isArray(sessions) || sessions.length === 0) return sessions;

  const creds = await getSupabaseCreds();
  if (!creds) {
    console.error('Supabase credentials could not be loaded from SSM for recorded sessions.');
    return sessions;
  }

  const supabaseUrl = creds.url;
  const serviceRoleKey = creds.key;
  const bucket = process.env.SUPABASE_STORAGE_BUCKET || 'PMX';

  const promises = sessions.map(async (session) => {
    if (session.storageProvider === 'supabase' && session.storagePath) {
      try {
        const signedUrlRes = await fetch(
          `${supabaseUrl}/storage/v1/object/sign/${bucket}/${session.storagePath}`,
          {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${serviceRoleKey}`,
              apikey: serviceRoleKey,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ expiresIn: 60 * 60 * 24 * 365 * 10 }), // 10 years — effectively no expiry
          }
        );
        if (signedUrlRes.ok) {
          const resBody = await signedUrlRes.json();
          const rawSigned = resBody.signedUrl || resBody.signedURL || '';
          const fullSignedUrl = rawSigned.startsWith('http')
            ? rawSigned
            : `${supabaseUrl}/storage/v1${rawSigned}`;
          return {
            ...session,
            url: fullSignedUrl,
          };
        } else {
          console.error(`Supabase returned status ${signedUrlRes.status} for signing path ${session.storagePath}`);
        }
      } catch (err) {
        console.error('Error generating signed URL for session path:', session.storagePath, err);
      }
    }
    return session;
  });

  return Promise.all(promises);
}

async function signWeekVideos(weeks) {
  if (!Array.isArray(weeks) || weeks.length === 0) return weeks;

  const creds = await getSupabaseCreds();
  if (!creds) {
    console.error('Supabase credentials could not be loaded from SSM for week videos.');
    return weeks;
  }

  const supabaseUrl = creds.url;
  const serviceRoleKey = creds.key;
  const bucket = process.env.SUPABASE_STORAGE_BUCKET || 'PMX';

  const promises = weeks.map(async (week) => {
    if (week.storageProvider === 'supabase' && week.storagePath) {
      try {
        const signedUrlRes = await fetch(
          `${supabaseUrl}/storage/v1/object/sign/${bucket}/${week.storagePath}`,
          {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${serviceRoleKey}`,
              apikey: serviceRoleKey,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ expiresIn: 60 * 60 * 24 * 365 * 10 }), // 10 years — effectively no expiry
          }
        );
        if (signedUrlRes.ok) {
          const resBody = await signedUrlRes.json();
          const rawSigned = resBody.signedUrl || resBody.signedURL || '';
          const fullSignedUrl = rawSigned.startsWith('http')
            ? rawSigned
            : `${supabaseUrl}/storage/v1${rawSigned}`;
          return {
            ...week,
            url: fullSignedUrl,
          };
        }
      } catch (err) {
        console.error('Error generating signed URL for week path:', week.storagePath, err);
      }
    }
    return week;
  });

  return Promise.all(promises);
}

async function getSupplementalContent(courseId) {
  const result = await ddb.send(new GetCommand({
    TableName: COURSES_TABLE,
    Key: { pk: `COURSE#${courseId}`, sk: SUPPLEMENTAL_SK },
  }));

  const item = result.Item || {};
  const rawSessions = Array.isArray(item.liveRecordedSessions) ? item.liveRecordedSessions : [];
  const signedSessions = await signRecordedSessions(rawSessions);

  return {
    assignments: Array.isArray(item.assignments) ? item.assignments : [],
    liveRecordedSessions: signedSessions,
    calendarEvents: Array.isArray(item.calendarEvents) ? item.calendarEvents : [],
    reminders: Array.isArray(item.reminders) ? item.reminders : [],
    resources: Array.isArray(item.resources) ? item.resources : [],
    updatedAt: item.updatedAt || null,
    createdAt: item.createdAt || null,
  };
}

// ── Auth guard ────────────────────────────────────────────────────────────────

function isAdminUser(event) {
  const groupsClaim = event.requestContext?.authorizer?.claims?.['cognito:groups'];
  const groups = Array.isArray(groupsClaim)
    ? groupsClaim
    : typeof groupsClaim === 'string' ? groupsClaim.split(',') : [];
  return groups.includes('admins');
}

// ── Route handlers ────────────────────────────────────────────────────────────

// GET /admin/students
// Lists all Cognito users enrolled in the given courseId and flattens their attributes.
async function listStudents(courseId, event) {
  if (!courseId) {
    return res(400, { message: 'courseId query parameter is required' });
  }

  // 1. Get all enrollments for this course
  let enrollmentsResult;
  try {
    enrollmentsResult = await ddb.send(new ScanCommand({
      TableName: ENROLLMENTS_TABLE,
      FilterExpression: 'courseId = :cid',
      ExpressionAttributeValues: { ':cid': courseId }
    }));
  } catch (err) {
    console.error('Failed to fetch enrollments:', err);
    return res(500, { message: 'Failed to load enrolled roster' });
  }
  const enrolledUserIds = new Set((enrollmentsResult.Items || []).map(item => item.enrollmentId));

  // 2. Get all Cognito users
  const userPoolId = deriveUserPoolId(event);
  let result;
  try {
    result = await cognito.send(new ListUsersCommand({ UserPoolId: userPoolId }));
  } catch (err) {
    console.error('Failed to list Cognito users:', err);
    return res(500, { message: 'Failed to fetch Cognito users' });
  }

  // 3. Map all users and append enrollment status
  const students = (result.Users || [])
    .map((u) => {
      const attrs = {};
      for (const a of u.Attributes || []) attrs[a.Name] = a.Value;
      const enrolled = enrolledUserIds.has(u.Username) || enrolledUserIds.has(attrs.sub) || (attrs.email && enrolledUserIds.has(attrs.email));
      return {
        Username: u.Username,
        UserStatus: u.UserStatus,
        UserCreateDate: u.UserCreateDate,
        email: attrs.email || '',
        name: attrs.name || '',
        sub: attrs.sub || '',
        enrolled,
      };
    });

  return res(200, { students });
}

// POST /admin/students
// Creates a student in Cognito with a temporary password (FORCE_CHANGE_PASSWORD).
// The student must reset their password on first login. Also enrolls them in the specified courseId.
async function createStudent(body, event) {
  const { email, name, tempPassword, courseId } = body;
  if (!email || !name || !tempPassword || !courseId) {
    return res(400, { message: 'email, name, tempPassword, and courseId are required' });
  }

  const userPoolId = deriveUserPoolId(event);
  let createRes;
  try {
    createRes = await cognito.send(new AdminCreateUserCommand({
      UserPoolId: userPoolId,
      Username: email,
      TemporaryPassword: tempPassword,
      UserAttributes: [
        { Name: 'email', Value: email },
        { Name: 'email_verified', Value: 'true' },
        { Name: 'name', Value: name },
      ],
      MessageAction: 'SUPPRESS',
    }));
  } catch (err) {
    console.error('Failed to create student in Cognito:', err);
    if (err.name === 'UsernameExistsException' || err.code === 'UsernameExistsException') {
      try {
        const userObj = await cognito.send(new AdminGetUserCommand({
          UserPoolId: userPoolId,
          Username: email,
        }));
        const userId = userObj.UserAttributes?.find(a => a.Name === 'sub')?.Value || userObj.Username;
        await ddb.send(new PutCommand({
          TableName: ENROLLMENTS_TABLE,
          Item: {
            enrollmentId: userId,
            userId,
            courseId,
            enrolledAt: new Date().toISOString()
          }
        }));
        return res(200, { message: `Existing student ${email} successfully enrolled in ${courseId}` });
      } catch (enrollErr) {
        console.error('Failed to enroll existing student:', enrollErr);
        return res(400, { message: 'Account already exists, but enrolling to batch failed.' });
      }
    }
    return res(500, { message: err.message || 'Failed to create student.' });
  }

  const userId = createRes.User.Attributes.find(a => a.Name === 'sub')?.Value || createRes.User.Username;

  try {
    await ddb.send(new PutCommand({
      TableName: ENROLLMENTS_TABLE,
      Item: {
        enrollmentId: userId,
        userId,
        courseId,
        enrolledAt: new Date().toISOString()
      }
    }));
  } catch (err) {
    console.error('Failed to write student enrollment row:', err);
    return res(500, { message: 'Student created but enrollment mapping failed.' });
  }

  return res(201, { message: `Student ${email} created successfully and enrolled in ${courseId}` });
}

// GET /admin/courses/{courseId}/weeks
// Returns all weeks (including hidden ones) with full quiz data including correctIndex.
async function listWeeks(courseId) {
  const [result, supplementalContent, gymResult, blogResult, eventResult, ramayanaResult] = await Promise.all([
    ddb.send(new QueryCommand({
      TableName: COURSES_TABLE,
      KeyConditionExpression: 'pk = :pk AND begins_with(sk, :prefix)',
      ExpressionAttributeValues: {
        ':pk': `COURSE#${courseId}`,
        ':prefix': 'WEEK#',
      },
    })),
    getSupplementalContent(courseId),
    ddb.send(new QueryCommand({
      TableName: COURSES_TABLE,
      KeyConditionExpression: 'pk = :pk AND begins_with(sk, :prefix)',
      ExpressionAttributeValues: {
        ':pk': `COURSE#${courseId}`,
        ':prefix': 'GYM#',
      },
    })),
    ddb.send(new QueryCommand({
      TableName: COURSES_TABLE,
      KeyConditionExpression: 'pk = :pk AND begins_with(sk, :prefix)',
      ExpressionAttributeValues: {
        ':pk': 'BLOG#GLOBAL',
        ':prefix': 'POST#',
      },
    })),
    ddb.send(new QueryCommand({
      TableName: COURSES_TABLE,
      KeyConditionExpression: 'pk = :pk AND begins_with(sk, :prefix)',
      ExpressionAttributeValues: {
        ':pk': 'EVENT#GLOBAL',
        ':prefix': 'EVENT#',
      },
    })),
    ddb.send(new QueryCommand({
      TableName: COURSES_TABLE,
      KeyConditionExpression: 'pk = :pk AND begins_with(sk, :prefix)',
      ExpressionAttributeValues: {
        ':pk': 'RAMAYANA#GLOBAL',
        ':prefix': 'DROP#',
      },
    })),
  ]);

  const rawWeeks = (result.Items || [])
    .filter((item) => item.weekId !== '__supplemental__')
    .sort((a, b) => (a.weekNumber || 0) - (b.weekNumber || 0));

  const signedWeeks = await signWeekVideos(rawWeeks);

  const gymQuestions = (gymResult.Items || [])
    .sort((a, b) => (a.date || '').localeCompare(b.date || ''));

  const blogs = (blogResult.Items || [])
    .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));

  const events = (eventResult.Items || [])
    .sort((a, b) => (b.dateStr || '').localeCompare(a.dateStr || ''));

  const ramayanaDrops = (ramayanaResult.Items || [])
    .sort((a, b) => (Number(a.dayNumber) || 0) - (Number(b.dayNumber) || 0));

  return res(200, { weeks: signedWeeks, supplementalContent, gymQuestions, blogs, events, ramayanaDrops });
}

// POST /admin/courses/{courseId}/weeks
// Creates a new week. Generates a weekId if one is not provided.
async function createWeek(courseId, body) {
  const weekId = `week-${randomUUID().slice(0, 8)}`;
  const item = {
    pk: `COURSE#${courseId}`,
    sk: `WEEK#${weekId}`,
    weekId,
    courseId,
    category: body.category || 'module',
    weekNumber: body.weekNumber || 1,
    title: body.title || 'Untitled Week',
    weekTitle: body.weekTitle || '',
    description: body.description || '',
    youtubeUrl: body.youtubeUrl || null,
    qaLink: body.qaLink || null,
    visible: false,  // always starts hidden — admin must explicitly release
    quiz: body.quiz || { questions: [] },
    resources: body.resources || [],
    docs: body.docs || [],
    liveRecordedSessions: body.liveRecordedSessions || [],
    calendarEvents: body.calendarEvents || [],
    assignments: body.assignments || [],
    transcript: body.transcript || null,
    textContent: body.textContent || null,
    storagePath: body.storagePath || null,
    storageProvider: body.storageProvider || null,
    createdAt: new Date().toISOString(),
  };

  await ddb.send(new PutCommand({ TableName: COURSES_TABLE, Item: item }));
  return res(201, { week: item });
}

// PATCH /admin/courses/{courseId}/weeks/{weekId}
async function updateGymQuestion(courseId, body) {
  const { action } = body;
  if (action === 'save') {
    const { question } = body;
    if (!question || !question.date) {
      return res(400, { message: 'Question and date are required' });
    }
    const sk = `GYM#${question.date}`;
    const item = {
      pk: `COURSE#${courseId}`,
      sk,
      date: question.date,
      type: question.type, // 'quiz' | 'text'
      text: question.text,
      options: Array.isArray(question.options) ? question.options : null,
      correctIndex: typeof question.correctIndex === 'number' ? question.correctIndex : null,
      correctAnswer: question.correctAnswer || null,
      explanation: question.explanation || '',
      updatedAt: new Date().toISOString(),
    };
    await ddb.send(new PutCommand({
      TableName: COURSES_TABLE,
      Item: item,
    }));
    return res(200, { message: 'Gym question saved successfully', question: item });
  } else if (action === 'delete') {
    const { date } = body;
    if (!date) return res(400, { message: 'Date is required for delete' });
    await ddb.send(new DeleteCommand({
      TableName: COURSES_TABLE,
      Key: { pk: `COURSE#${courseId}`, sk: `GYM#${date}` },
    }));
    return res(200, { message: 'Gym question deleted successfully', date });
  }
  return res(400, { message: 'Invalid action for gym content' });
}

async function updateBlog(courseId, body) {
  const { action } = body;
  if (action === 'save') {
    const { blog } = body;
    if (!blog || !blog.id) {
      return res(400, { message: 'Blog and id are required' });
    }
    const sk = `POST#${blog.id}`;
    const item = {
      pk: 'BLOG#GLOBAL',
      sk,
      id: blog.id,
      title: blog.title,
      description: blog.description,
      content: blog.content || '',
      imageUrl: blog.imageUrl || '',
      date: blog.date || new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
      createdAt: blog.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await ddb.send(new PutCommand({
      TableName: COURSES_TABLE,
      Item: item,
    }));
    return res(200, { message: 'Blog post saved successfully', blog: item });
  } else if (action === 'delete') {
    const { id } = body;
    if (!id) return res(400, { message: 'Id is required for delete' });
    await ddb.send(new DeleteCommand({
      TableName: COURSES_TABLE,
      Key: { pk: 'BLOG#GLOBAL', sk: `POST#${id}` },
    }));
    return res(200, { message: 'Blog post deleted successfully', id });
  }
  return res(400, { message: 'Invalid action for blog content' });
}

async function updateEvent(courseId, body) {
  const { action } = body;
  if (action === 'save') {
    const { event } = body;
    if (!event || !event.id) {
      return res(400, { message: 'Event and id are required' });
    }
    const sk = `EVENT#${event.id}`;
    const item = {
      pk: 'EVENT#GLOBAL',
      sk,
      id: event.id,
      title: event.title || '',
      dateStr: event.dateStr || '',
      dateDisplay: event.dateDisplay || '',
      time: event.time || '',
      format: event.format || '',
      description: event.description || '',
      aboutText: event.aboutText || '',
      registerUrl: event.registerUrl || '',
      attendeeCount: Number(event.attendeeCount) || 0,
      moments: Array.isArray(event.moments) ? event.moments : [],
      hosts: Array.isArray(event.hosts) ? event.hosts : [],
      tags: Array.isArray(event.tags) ? event.tags : [],
      bannerBg: event.bannerBg || 'linear-gradient(135deg, #188ab2 0%, #1e40af 100%)',
      createdAt: event.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await ddb.send(new PutCommand({
      TableName: COURSES_TABLE,
      Item: item,
    }));
    return res(200, { message: 'Event saved successfully', event: item });
  } else if (action === 'delete') {
    const { id } = body;
    if (!id) return res(400, { message: 'Id is required for delete' });
    await ddb.send(new DeleteCommand({
      TableName: COURSES_TABLE,
      Key: { pk: 'EVENT#GLOBAL', sk: `EVENT#${id}` },
    }));
    return res(200, { message: 'Event deleted successfully', id });
  }
  return res(400, { message: 'Invalid action for event content' });
}

async function updateRamayanaDrop(courseId, body) {
  const { action } = body;
  if (action === 'save') {
    const { drop } = body;
    if (!drop || !drop.dayNumber) {
      return res(400, { message: 'Drop and dayNumber are required' });
    }
    const sk = `DROP#${drop.dayNumber}`;
    const item = {
      pk: 'RAMAYANA#GLOBAL',
      sk,
      dayNumber: Number(drop.dayNumber),
      title: drop.title || `Day ${drop.dayNumber}`,
      subtitle: drop.subtitle || '',
      theme: drop.theme || '',
      unlockDate: drop.unlockDate || new Date().toISOString().split('T')[0],
      isLocked: drop.isLocked !== undefined ? drop.isLocked : false,
      introLines: Array.isArray(drop.introLines) ? drop.introLines : [],
      imageUrl: drop.imageUrl || '/ayodhya_dawn.jpg',
      video: drop.video || {
        youtubeUrl: drop.youtubeUrl || drop.video?.youtubeUrl || '',
        headline: drop.video?.headline || '“I have no heir. Fix this.”',
        caption: drop.video?.caption || 'King Dasharatha summons you to the royal court of Ayodhya.',
      },
      youtubeUrl: drop.youtubeUrl || drop.video?.youtubeUrl || '',
      poll: drop.poll || null,
      openQuestion: drop.openQuestion || null,
      cliffhanger: drop.cliffhanger || '',
      interviews: drop.interviews || null,
      conflictTwist: drop.conflictTwist || null,
      synthesis: drop.synthesis || null,
      postTest: drop.postTest || null,
      feedback: drop.feedback || null,
      updatedAt: new Date().toISOString(),
      createdAt: drop.createdAt || new Date().toISOString(),
    };
    await ddb.send(new PutCommand({
      TableName: COURSES_TABLE,
      Item: item,
    }));
    return res(200, { message: 'Ramayana drop saved successfully', drop: item });
  } else if (action === 'delete') {
    const { dayNumber } = body;
    if (!dayNumber) return res(400, { message: 'dayNumber is required for delete' });
    await ddb.send(new DeleteCommand({
      TableName: COURSES_TABLE,
      Key: { pk: 'RAMAYANA#GLOBAL', sk: `DROP#${dayNumber}` },
    }));
    return res(200, { message: 'Ramayana drop deleted successfully', dayNumber });
  }
  return res(400, { message: 'Invalid action for Ramayana chronicle' });
}

// Updates any subset of week fields. Commonly used to toggle visibility.
async function updateWeek(courseId, weekId, body) {
  console.log('DEPLOY_CHECK_V2: updateWeek called with weekId =', weekId);
  if (weekId === '__gym__') {
    console.log('DEPLOY_CHECK_V2: Redirecting to updateGymQuestion');
    return await updateGymQuestion(courseId, body);
  }
  if (weekId === '__blog__') {
    console.log('DEPLOY_CHECK_V2: Redirecting to updateBlog');
    return await updateBlog(courseId, body);
  }
  if (weekId === '__event__') {
    console.log('DEPLOY_CHECK_V2: Redirecting to updateEvent');
    return await updateEvent(courseId, body);
  }
  if (weekId === '__ramayana__' || weekId === '__chronicle__' || weekId.startsWith('__ramayana')) {
    console.log('DEPLOY_CHECK_V2: Redirecting to updateRamayanaDrop');
    return await updateRamayanaDrop(courseId, body);
  }
  // Guard: if this is actually a supplemental content update, redirect to the correct handler.
  // This ensures data is always saved to SUPPLEMENTAL#GLOBAL (not WEEK#__supplemental__).
  if (weekId === '__supplemental__') {
    console.log('DEPLOY_CHECK_V2: Redirecting to updateSupplementalContent');
    return await updateSupplementalContent(courseId, body);
  }

  // Handle upload URL request for week video
  if (body && body.action === 'getUploadUrl') {
    const { fileName } = body;
    if (!fileName) {
      return res(400, { message: 'fileName is required for getUploadUrl action' });
    }

    const supabaseUrl = process.env.SUPABASE_URL;
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    const bucket = process.env.SUPABASE_STORAGE_BUCKET;

    if (!supabaseUrl || !serviceRoleKey || !bucket) {
      return res(500, { message: 'Supabase credentials not configured on backend' });
    }

    const safeFileName = fileName.replace(/[^a-zA-Z0-9.-]/g, '_');
    const storagePath = `week-videos/${Date.now()}-${safeFileName}`;

    try {
      const uploadSignRes = await fetch(
        `${supabaseUrl}/storage/v1/object/upload/sign/${bucket}/${storagePath}`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${serviceRoleKey}`,
            apikey: serviceRoleKey,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({}),
        }
      );

      if (uploadSignRes.ok) {
        const signBody = await uploadSignRes.json();
        const rawUrl = signBody.url || signBody.signedUrl || signBody.signedURL || '';
        const fullUrl = rawUrl.startsWith('http')
          ? rawUrl
          : `${supabaseUrl}/storage/v1${rawUrl}`;

        return res(200, {
          signedUrl: fullUrl,
          storagePath,
          storageProvider: 'supabase',
        });
      } else {
        const errorText = await uploadSignRes.text();
        console.error('Supabase signed upload URL fetch error for week:', errorText);
        return res(500, { message: `Supabase upload signing failed: ${errorText}` });
      }
    } catch (err) {
      console.error('Error fetching signed upload URL from Supabase for week:', err);
      return res(500, { message: err.message || 'Internal server error' });
    }
  }

  // Build a dynamic UpdateExpression from whatever fields were provided.
  const fields = [
    'title', 'description', 'youtubeUrl', 'qaLink', 'visible', 'weekNumber',
    'category', 'quiz', 'resources', 'docs', 'assignments', 'liveRecordedSessions',
    'calendarEvents', 'transcript', 'weekTitle', 'textContent', 'storagePath', 'storageProvider'
  ];
  const setClauses = [];
  const exprAttrValues = {};
  const exprAttrNames = {};

  for (const field of fields) {
    if (body[field] !== undefined) {
      // 'visible' and 'quiz' are not reserved words in DynamoDB, but 'description' might be in some contexts.
      // Use attribute name aliasing for safety on all fields.
      const alias = `#f_${field}`;
      const valAlias = `:v_${field}`;
      setClauses.push(`${alias} = ${valAlias}`);
      exprAttrNames[alias] = field;
      exprAttrValues[valAlias] = body[field];
    }
  }

  if (setClauses.length === 0) return res(400, { message: 'No updatable fields provided' });

  exprAttrNames['#updAt'] = 'updatedAt';
  exprAttrValues[':updAt'] = new Date().toISOString();
  setClauses.push('#updAt = :updAt');

  await ddb.send(new UpdateCommand({
    TableName: COURSES_TABLE,
    Key: { pk: `COURSE#${courseId}`, sk: `WEEK#${weekId}` },
    UpdateExpression: `SET ${setClauses.join(', ')}`,
    ExpressionAttributeNames: exprAttrNames,
    ExpressionAttributeValues: exprAttrValues,
  }));

  return res(200, { message: 'Week updated V3', weekId });
}

async function updateSupplementalContent(courseId, body) {
  if (body && body.action === 'getUploadUrl') {
    const { fileName, mimeType } = body;
    if (!fileName) {
      return res(400, { message: 'fileName is required for getUploadUrl action' });
    }

    const supabaseUrl = process.env.SUPABASE_URL;
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    const bucket = process.env.SUPABASE_STORAGE_BUCKET;

    if (!supabaseUrl || !serviceRoleKey || !bucket) {
      return res(500, { message: 'Supabase credentials not configured on backend' });
    }

    const safeFileName = fileName.replace(/[^a-zA-Z0-9.-]/g, '_');
    const storagePath = `global-sessions/${Date.now()}-${safeFileName}`;

    try {
      const uploadSignRes = await fetch(
        `${supabaseUrl}/storage/v1/object/upload/sign/${bucket}/${storagePath}`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${serviceRoleKey}`,
            apikey: serviceRoleKey,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({}),
        }
      );

      if (uploadSignRes.ok) {
        const signBody = await uploadSignRes.json();
        const rawUrl = signBody.url || signBody.signedUrl || signBody.signedURL || '';
        const fullUrl = rawUrl.startsWith('http')
          ? rawUrl
          : `${supabaseUrl}/storage/v1${rawUrl}`;

        return res(200, {
          signedUrl: fullUrl,
          storagePath,
          storageProvider: 'supabase',
        });
      } else {
        const errorText = await uploadSignRes.text();
        console.error('Supabase signed upload URL fetch error:', errorText);
        return res(500, { message: `Supabase upload signing failed: ${errorText}` });
      }
    } catch (err) {
      console.error('Error fetching signed upload URL from Supabase:', err);
      return res(500, { message: err.message || 'Internal server error' });
    }
  }

  const hasSupportedField = ['assignments', 'liveRecordedSessions', 'calendarEvents', 'reminders', 'resources']
    .some((field) => body[field] !== undefined);
  if (!hasSupportedField) {
    return res(400, { message: 'No supplemental fields provided' });
  }

  const existing = await getSupplementalContent(courseId);
  const now = new Date().toISOString();

  const nextContent = {
    assignments: body.assignments !== undefined ? body.assignments : existing.assignments,
    liveRecordedSessions: body.liveRecordedSessions !== undefined ? body.liveRecordedSessions : existing.liveRecordedSessions,
    calendarEvents: body.calendarEvents !== undefined ? body.calendarEvents : existing.calendarEvents,
    reminders: body.reminders !== undefined ? body.reminders : existing.reminders,
    resources: body.resources !== undefined ? body.resources : existing.resources,
  };

  await ddb.send(new PutCommand({
    TableName: COURSES_TABLE,
    Item: {
      pk: `COURSE#${courseId}`,
      sk: SUPPLEMENTAL_SK,
      courseId,
      ...nextContent,
      createdAt: existing.createdAt || now,
      updatedAt: now,
    },
  }));

  return res(200, { message: 'Supplemental content updated', version: 'V2', supplementalContent: nextContent });
}

// DELETE /admin/courses/{courseId}/weeks/{weekId}
async function deleteWeek(courseId, weekId) {
  await ddb.send(new DeleteCommand({
    TableName: COURSES_TABLE,
    Key: { pk: `COURSE#${courseId}`, sk: `WEEK#${weekId}` },
  }));
  return res(200, { message: 'Week deleted', weekId });
}

// GET /admin/courses/{courseId}/progress
// Scans all progress records for a course across all students.
// At 20 students × ~10 weeks = 200 items, a Scan is fine.
// At larger scale, add a GSI on (courseId, weekId).
async function getCourseProgress(courseId) {
  const result = await ddb.send(new ScanCommand({
    TableName: PROGRESS_TABLE,
    FilterExpression: 'courseId = :cid',
    ExpressionAttributeValues: { ':cid': courseId },
  }));

  const progress = [];
  const gymSubmissions = [];

  for (const item of (result.Items || [])) {
    if (item.sk && item.sk.startsWith('GYM#')) {
      gymSubmissions.push({
        userId: item.userId || (item.pk ? item.pk.replace('USER#', '') : ''),
        date: item.date,
        type: item.type,
        answer: item.answer,
        score: item.score,
        submittedAt: item.submittedAt,
      });
    } else {
      progress.push({
        userId: item.userId || (item.pk ? item.pk.replace('USER#', '') : ''),
        weekId: item.weekId,
        videoComplete: item.videoComplete || false,
        watchedSegments: item.watchedSegments ? [...item.watchedSegments] : [],
        quizPassed: item.quizPassed || false,
        quizScore: item.quizScore ?? null,
        quizTotal: item.quizTotal ?? null,
        quizAttempts: item.quizAttempts || 0,
        lastSeen: item.lastSeen || null,
      });
    }
  }

  return res(200, { progress, gymSubmissions });
}

// GET /admin/courses/{courseId}/submissions
async function getSubmissions(courseId) {
  const result = await ddb.send(new ScanCommand({
    TableName: process.env.ASSIGNMENTS_TABLE || process.env.ASSIGNMENT_TABLE || 'lms-assignments',
    FilterExpression: 'courseId = :cid',
    ExpressionAttributeValues: { ':cid': courseId },
  }));

  const submissions = result.Items || [];

  const creds = await getSupabaseCreds();
  if (creds) {
    const supabaseUrl = creds.url;
    const serviceRoleKey = creds.key;
    const bucket = process.env.SUPABASE_STORAGE_BUCKET || 'PMX';

    for (const sub of submissions) {
      // Use storagePath (preferred) for all supabase items — always regenerate fresh signed URLs
      // so that old DynamoDB-stored driveUrls (which expire after 24h) are never served stale.
      if (sub.storageProvider === 'supabase' && sub.storagePath) {
        try {
          const signedUrlRes = await fetch(
            `${supabaseUrl}/storage/v1/object/sign/${bucket}/${sub.storagePath}`,
            {
              method: 'POST',
              headers: {
                Authorization: `Bearer ${serviceRoleKey}`,
                apikey: serviceRoleKey,
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({ expiresIn: 60 * 60 * 24 * 365 * 10 }), // 10 years — effectively no expiry
            }
          );
          if (signedUrlRes.ok) {
            const body = await signedUrlRes.json();
            const rawSigned = body.signedUrl || body.signedURL || '';
            sub.driveUrl = rawSigned.startsWith('http') ? rawSigned : `${supabaseUrl}/storage/v1${rawSigned}`;
          } else {
            // Signing failed (e.g. Supabase rate limit) — null out the stale stored URL
            // so the frontend shows a clear 'unavailable' state rather than an expired JWT error.
            console.warn('Supabase sign failed for', sub.storagePath, signedUrlRes.status);
            sub.driveUrl = null;
          }
        } catch (err) {
          console.error('Error generating signed URL for', sub.storagePath, err);
          // Null out so frontend knows the link is broken, not expired
          sub.driveUrl = null;
        }
      }
    }
  }

  submissions.sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime());

  return res(200, { submissions });
}

// GET /admin/leads
// Returns all leads/enrollments from the landing page form.
async function listLeads() {
  const result = await ddb.send(new ScanCommand({
    TableName: ENROLLMENTS_TABLE,
  }));

  const leads = (result.Items || [])
    .filter(item => item.masterclassId) // Exclude student enrollments!
    .sort((a, b) => {
      const dateA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
      const dateB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
      return dateB - dateA;
    });

  return res(200, { leads });
}

// ── Batches / Courses ────────────────────────────────────────────────────────
async function createCourse(body) {
  let { courseId, name, description } = body || {};

  if (!name && !courseId) {
    return res(400, { message: 'Course name or courseId is required' });
  }

  // Auto-generate courseId if not provided
  if (!courseId) {
    try {
      const existing = await ddb.send(new ScanCommand({
        TableName: COURSES_TABLE,
        FilterExpression: 'sk = :meta',
        ExpressionAttributeValues: { ':meta': 'METADATA' },
      }));
      const count = (existing.Items || []).length;
      courseId = `course-${String(count + 1).padStart(3, '0')}`;
    } catch (err) {
      console.error('Scan courses error:', err);
      courseId = `course-${Date.now()}`;
    }
  }

  // Ensure standard formatting e.g. "3" -> "course-003"
  if (!courseId.startsWith('course-')) {
    const num = parseInt(courseId, 10);
    if (!isNaN(num)) {
      courseId = `course-${String(num).padStart(3, '0')}`;
    }
  }

  if (!name) {
    const batchNum = courseId.replace('course-', '').replace(/^0+/, '');
    name = `PM -X Accelerator (Batch ${batchNum || courseId})`;
  }

  const item = {
    pk: `COURSE#${courseId}`,
    sk: 'METADATA',
    courseId,
    name,
    description: description || '',
    createdAt: new Date().toISOString()
  };

  try {
    await ddb.send(new PutCommand({
      TableName: COURSES_TABLE,
      Item: item
    }));
    return res(201, {
      message: `Batch ${name} created successfully`,
      course: {
        courseId,
        name,
        description: item.description,
        createdAt: item.createdAt
      }
    });
  } catch (err) {
    console.error('Failed to create course:', err);
    return res(500, { message: 'Failed to create course in database' });
  }
}

// ── Main handler ──────────────────────────────────────────────────────────────

exports.handler = async (event) => {
  currentOrigin = event?.headers?.origin || event?.headers?.Origin || FRONTEND_URL;
  if (event.httpMethod === 'OPTIONS') return res(200, {});

  // Layer 2 admin check — even if React's AdminRoute is bypassed, this rejects non-admins.
  if (!isAdminUser(event)) {
    return res(403, { message: 'Forbidden: admin access required' });
  }

  const method = event.httpMethod;
  const resource = (event.resource || '')
    .replace('{courseID}', '{courseId}')
    .replace('{weekID}', '{weekId}');
  const params = event.pathParameters || {};
  const courseId = params.courseId || params.courseID || event.queryStringParameters?.courseId;
  const weekId = params.weekId || params.weekID;
  const path = event.path || '';

  let body = {};
  try {
    if (event.body) body = JSON.parse(event.body);
  } catch {
    return res(400, { message: 'Invalid JSON body' });
  }

  try {
    // ── Batches / Courses ─────────────────────────────────────────────
    if (method === 'POST' && (resource === '/admin/courses' || resource === '/admin/batches' || resource === '/admin/courses/create' || path.endsWith('/admin/courses') || path.endsWith('/admin/batches'))) {
      return await createCourse(body);
    }

    // ── Students ──────────────────────────────────────────────────────
    if (method === 'GET' && resource === '/admin/students') return await listStudents(courseId, event);
    if (method === 'POST' && resource === '/admin/students') return await createStudent(body, event);

    // ── Weeks ─────────────────────────────────────────────────────────
    if (method === 'GET' && resource === '/admin/courses/{courseId}/weeks') return await listWeeks(courseId);
    if (method === 'POST' && resource === '/admin/courses/{courseId}/weeks') return await createWeek(courseId, body);
    if (method === 'PATCH' && resource === '/admin/courses/{courseId}/weeks/{weekId}' && weekId === '__supplemental__') {
      return await updateSupplementalContent(courseId, body);
    }
    if (method === 'PATCH' && resource === '/admin/courses/{courseId}/weeks/{weekId}') return await updateWeek(courseId, weekId, body);
    if (method === 'DELETE' && resource === '/admin/courses/{courseId}/weeks/{weekId}') return await deleteWeek(courseId, weekId);

    // ── Progress ──────────────────────────────────────────────────────
    if (method === 'GET' && resource === '/admin/courses/{courseId}/progress') return await getCourseProgress(courseId);

    // ── Assignments ──────────────────────────────────────────────────────
    if (method === 'GET' && resource === '/admin/courses/{courseId}/submissions') return await getSubmissions(courseId);

    // ── Leads ─────────────────────────────────────────────────────────
    if (method === 'GET' && resource === '/admin/leads') return await listLeads();

    return res(404, { message: `No handler for ${method} ${resource}` });
  } catch (err) {
    console.error(`Admin handler error [${method} ${resource}]:`, err);
    return res(500, { message: err.message || 'Internal server error' });
  }
};
