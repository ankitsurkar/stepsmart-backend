const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, QueryCommand, GetCommand, UpdateCommand, ScanCommand, PutCommand, DeleteCommand } = require('@aws-sdk/lib-dynamodb');
const { CognitoIdentityProviderClient, ListUsersCommand } = require('@aws-sdk/client-cognito-identity-provider');
const { SSMClient, GetParameterCommand } = require('@aws-sdk/client-ssm');
const { SESClient, SendEmailCommand } = require('@aws-sdk/client-ses');
const nodemailer = require('nodemailer');
const crypto = require('crypto');

const ssm = new SSMClient({ region: process.env.AWS_REGION || 'eu-north-1' });
const ses = new SESClient({ region: process.env.AWS_REGION || 'eu-north-1' });

let cachedSupaUrl = null;
let cachedSupaKey = null;

async function getSupabaseCreds() {
  if (cachedSupaUrl && cachedSupaKey) {
    return { url: cachedSupaUrl, key: cachedSupaKey };
  }
  try {
    const [urlRes, keyRes] = await Promise.all([
      ssm.send(new GetParameterCommand({ Name: '/stepsmart/supabase/url' })),
      ssm.send(new GetParameterCommand({ Name: '/stepsmart/supabase/service-role-key', WithDecryption: true })),
    ]);
    cachedSupaUrl = urlRes.Parameter.Value;
    cachedSupaKey = keyRes.Parameter.Value;
    return { url: cachedSupaUrl, key: cachedSupaKey };
  } catch (err) {
    console.error('Error fetching Supabase credentials from SSM Parameter Store:', err);
    return null;
  }
}

const ddbClient = new DynamoDBClient({ region: process.env.AWS_REGION || 'eu-north-1' });
const ddb = DynamoDBDocumentClient.from(ddbClient, {
  marshallOptions: { convertEmptyValues: true },
});
const cognito = new CognitoIdentityProviderClient({ region: process.env.AWS_REGION || 'eu-north-1' });

const COURSES_TABLE = process.env.COURSES_TABLE || 'lms-courses';
const PROGRESS_TABLE = process.env.PROGRESS_TABLE || 'lms-progress';
const ASSIGNMENTS_TABLE = process.env.ASSIGNMENTS_TABLE || process.env.ASSIGNMENT_TABLE || 'lms-assignments';
const ENROLLMENTS_TABLE = process.env.ENROLLMENTS_TABLE || 'lms-enrollments';
const PEER_SESSIONS_TABLE = process.env.PEER_SESSIONS_TABLE || 'lms-peer-sessions';
const FROM_EMAIL = process.env.FROM_EMAIL || 'admin@stepsmart.net';
const GMAIL_USER = process.env.GMAIL_USER || 'admin@stepsmart.net';
const GMAIL_APP_PASSWORD = (process.env.GMAIL_APP_PASSWORD || 'xrnlzbaomictijlt').replace(/\s+/g, '');

let mailTransporter = null;
function getMailTransporter() {
  if (mailTransporter) return mailTransporter;
  if (GMAIL_USER && GMAIL_APP_PASSWORD) {
    try {
      mailTransporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: GMAIL_USER,
          pass: GMAIL_APP_PASSWORD,
        },
      });
    } catch (err) {
      console.error('Failed to create nodemailer transporter:', err);
    }
  }
  return mailTransporter;
}

async function sendEmailNotification({ to, subject, html }) {
  if (!to) return;
  const fromEmail = FROM_EMAIL || GMAIL_USER || 'admin@stepsmart.net';
  const transporter = getMailTransporter();

  if (transporter) {
    try {
      const info = await transporter.sendMail({
        from: `"StepSmart LMS" <${fromEmail}>`,
        to,
        subject,
        html,
      });
      console.log(`Email successfully delivered via Gmail SMTP to: ${to} (Message ID: ${info.messageId})`);
      return info;
    } catch (smtpErr) {
      console.error(`Gmail SMTP delivery failed for ${to}, falling back to SES:`, smtpErr.message || smtpErr);
    }
  }

  // Fallback to SES if SMTP is unavailable or failed
  return ses.send(new SendEmailCommand({
    Source: fromEmail,
    Destination: { ToAddresses: Array.isArray(to) ? to : [to] },
    Message: {
      Subject: { Data: subject },
      Body: { Html: { Data: html } },
    },
  })).then(() => {
    console.log(`Confirmation email sent via SES fallback to: ${to}`);
  }).catch((sesErr) => {
    console.error(`Failed to send email to ${to} via SES fallback:`, sesErr.message || sesErr);
    throw sesErr;
  });
}
const FRONTEND_URL = process.env.FRONTEND_URL || 'https://stepsmart.net';
const PASSING_PCT = 70;
const HEARTBEAT_INTERVAL = 10;
const COMPLETION_THRESHOLD = 0.8;
const SUPPLEMENTAL_SK = 'SUPPLEMENTAL#GLOBAL';

let currentOrigin = FRONTEND_URL;

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': currentOrigin,
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
  };
}

function res(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', ...corsHeaders() },
    body: JSON.stringify(body),
  };
}

function normalizeResource(resource = '') {
  return resource
    .replace('{courseID}', '{courseId}')
    .replace('{weekID}', '{weekId}')
    .replace('{sessionID}', '{sessionId}');
}

const { BATCH_2_PRODUCT_DESIGN_CASE_STUDY } = require('./batch2GymQuestions');
const { AI_GYM_CHALLENGES } = require('./aiGymQuestions');

const COURSE_NAME_OVERRIDES = {
  'course-001': 'PM -X Accelerator',
  'course-002': 'PM -X Accelerator (Batch 2)',
  'course-ai-001': 'AI Seekho, AI Apnao',
};

async function checkEnrollment(userId, courseId, event) {
  // 1. Admins bypass enrollment checks
  const groupsClaim = event?.requestContext?.authorizer?.claims?.['cognito:groups'];
  const groups = Array.isArray(groupsClaim)
    ? groupsClaim
    : typeof groupsClaim === 'string' ? groupsClaim.split(',') : [];
  if (groups.includes('admins')) return true;

  if (!courseId) return false;

  // 2. Fetch user's enrollment
  try {
    const result = await ddb.send(new GetCommand({
      TableName: ENROLLMENTS_TABLE,
      Key: { enrollmentId: userId },
    }));
    return result.Item && result.Item.courseId === courseId;
  } catch (err) {
    console.error('checkEnrollment error:', err);
    return false;
  }
}

async function listMyCourses(userId, event) {
  const groupsClaim = event?.requestContext?.authorizer?.claims?.['cognito:groups'];
  const groups = Array.isArray(groupsClaim)
    ? groupsClaim
    : typeof groupsClaim === 'string' ? groupsClaim.split(',') : [];
  const isAdmin = groups.includes('admins');

  if (isAdmin) {
    const result = await ddb.send(new ScanCommand({
      TableName: COURSES_TABLE,
      FilterExpression: 'sk = :meta',
      ExpressionAttributeValues: { ':meta': 'METADATA' },
    }));
    const courses = (result.Items || []).map((item) => ({
      courseId: item.courseId,
      name: item.name || COURSE_NAME_OVERRIDES[item.courseId] || item.courseId,
      description: item.description || '',
    }));
    return res(200, { courses });
  }

  // Regular students only see their enrolled course
  let enrollment;
  try {
    const result = await ddb.send(new GetCommand({
      TableName: ENROLLMENTS_TABLE,
      Key: { enrollmentId: userId },
    }));
    enrollment = result.Item;
  } catch (err) {
    console.error('Failed to fetch user enrollment:', err);
    return res(500, { message: 'Failed to load enrollment' });
  }

  if (!enrollment || !enrollment.courseId) {
    return res(200, { courses: [] });
  }

  const enrolledCourseId = enrollment.courseId;
  let courseMeta;
  try {
    const result = await ddb.send(new GetCommand({
      TableName: COURSES_TABLE,
      Key: { pk: `COURSE#${enrolledCourseId}`, sk: 'METADATA' },
    }));
    courseMeta = result.Item;
  } catch (err) {
    console.error('Failed to fetch course metadata:', err);
    return res(500, { message: 'Failed to load course' });
  }

  if (!courseMeta) {
    return res(200, { courses: [] });
  }

  const courses = [{
    courseId: courseMeta.courseId,
    name: courseMeta.name || COURSE_NAME_OVERRIDES[courseMeta.courseId] || courseMeta.courseId,
    description: courseMeta.description || '',
  }];

  return res(200, { courses });
}

async function signRecordedSessions(sessions) {
  if (!Array.isArray(sessions) || sessions.length === 0) return sessions;

  const creds = await getSupabaseCreds();
  if (!creds) {
    console.error('Supabase credentials could not be loaded from SSM for recorded sessions.');
    return sessions;
  }

  const supabaseUrl = creds.url;
  const serviceRoleKey = creds.key;
  const bucket = process.env.SUPABASE_STORAGE_BUCKET || 'PMX';

  const promises = sessions.map(async (session) => {
    if (session.storageProvider === 'supabase' && session.storagePath) {
      try {
        const signedUrlRes = await fetch(
          `${supabaseUrl}/storage/v1/object/sign/${bucket}/${session.storagePath}`,
          {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${serviceRoleKey}`,
              apikey: serviceRoleKey,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ expiresIn: 60 * 60 * 24 * 365 * 10 }), // 10 years — effectively no expiry
          }
        );
        if (signedUrlRes.ok) {
          const resBody = await signedUrlRes.json();
          const rawSigned = resBody.signedUrl || resBody.signedURL || '';
          const fullSignedUrl = rawSigned.startsWith('http')
            ? rawSigned
            : `${supabaseUrl}/storage/v1${rawSigned}`;
          return {
            ...session,
            url: fullSignedUrl,
          };
        } else {
          console.error(`Supabase returned status ${signedUrlRes.status} for signing path ${session.storagePath}`);
        }
      } catch (err) {
        console.error('Error generating signed URL for session path:', session.storagePath, err);
      }
    }
    return session;
  });

  return Promise.all(promises);
}

async function signWeekVideos(weeks) {
  if (!Array.isArray(weeks) || weeks.length === 0) return weeks;

  const creds = await getSupabaseCreds();
  if (!creds) {
    console.error('Supabase credentials could not be loaded from SSM for week videos.');
    return weeks;
  }

  const supabaseUrl = creds.url;
  const serviceRoleKey = creds.key;
  const bucket = process.env.SUPABASE_STORAGE_BUCKET || 'PMX';

  const promises = weeks.map(async (week) => {
    if (week.storageProvider === 'supabase' && week.storagePath) {
      try {
        const signedUrlRes = await fetch(
          `${supabaseUrl}/storage/v1/object/sign/${bucket}/${week.storagePath}`,
          {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${serviceRoleKey}`,
              apikey: serviceRoleKey,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ expiresIn: 60 * 60 * 24 * 365 * 10 }), // 10 years — effectively no expiry
          }
        );
        if (signedUrlRes.ok) {
          const resBody = await signedUrlRes.json();
          const rawSigned = resBody.signedUrl || resBody.signedURL || '';
          const fullSignedUrl = rawSigned.startsWith('http')
            ? rawSigned
            : `${supabaseUrl}/storage/v1${rawSigned}`;
          return {
            ...week,
            url: fullSignedUrl,
          };
        }
      } catch (err) {
        console.error('Error generating signed URL for week path:', week.storagePath, err);
      }
    }
    return week;
  });

  return Promise.all(promises);
}

async function getSupplementalContent(courseId) {
  try {
    const result = await ddb.send(new GetCommand({
      TableName: COURSES_TABLE,
      Key: { pk: `COURSE#${courseId}`, sk: SUPPLEMENTAL_SK },
    }));
    const item = result.Item || {};
    const rawSessions = Array.isArray(item.liveRecordedSessions) ? item.liveRecordedSessions : [];
    const signedSessions = await signRecordedSessions(rawSessions);

    return {
      assignments: Array.isArray(item.assignments) ? item.assignments : [],
      liveRecordedSessions: signedSessions,
      calendarEvents: Array.isArray(item.calendarEvents) ? item.calendarEvents : [],
      reminders: Array.isArray(item.reminders) ? item.reminders : [],
      resources: Array.isArray(item.resources) ? item.resources : [],
    };
  } catch (err) {
    console.error('DynamoDB GetCommand supplemental content error:', err);
    return {
      assignments: [],
      liveRecordedSessions: [],
      calendarEvents: [],
      reminders: [],
      resources: [],
    };
  }
}

async function listCourseWeeks(courseId, event) {
  if (!courseId) return res(400, { message: 'Missing courseId path parameter' });

  const groupsClaim = event.requestContext?.authorizer?.claims?.['cognito:groups'];
  const groups = Array.isArray(groupsClaim)
    ? groupsClaim
    : typeof groupsClaim === 'string' ? groupsClaim.split(',') : [];
  const isAdmin = groups.includes('admins');

  let items;
  const supplementalContentPromise = getSupplementalContent(courseId);
  try {
    const result = await ddb.send(new QueryCommand({
      TableName: COURSES_TABLE,
      KeyConditionExpression: 'pk = :pk AND begins_with(sk, :prefix)',
      ExpressionAttributeValues: {
        ':pk': `COURSE#${courseId}`,
        ':prefix': 'WEEK#',
      },
    }));
    items = (result.Items || []).filter((item) => item.weekId !== '__supplemental__');
  } catch (err) {
    console.error('DynamoDB QueryCommand error:', err);
    return res(500, { message: 'Failed to load course weeks' });
  }

  const supplementalContent = await supplementalContentPromise;

  function hasSupplementalStudentContent(week) {
    return (week.assignments?.length || 0) > 0
      || (week.liveRecordedSessions?.length || 0) > 0
      || (week.calendarEvents?.length || 0) > 0;
  }

  const filtered = items
    .filter((w) => isAdmin || w.visible === true || hasSupplementalStudentContent(w))
    .sort((a, b) => (a.weekNumber || 0) - (b.weekNumber || 0));

  const signedWeeks = await signWeekVideos(filtered);

  const weeks = signedWeeks.map((w) => ({
    weekId: w.weekId,
    courseId: w.courseId || courseId,
    weekNumber: w.weekNumber,
    title: w.title,
    weekTitle: w.weekTitle || '',
    description: w.description,
    youtubeUrl: w.youtubeUrl || null,
    qaLink: w.qaLink || null,
    visible: w.visible || false,
    resources: w.resources || [],
    docs: w.docs || [],
    transcript: w.transcript || null,
    textContent: w.textContent || null,
    assignments: w.assignments || [],
    liveRecordedSessions: w.liveRecordedSessions || [],
    calendarEvents: w.calendarEvents || [],
    createdAt: w.createdAt || null,
    category: w.category || 'module',
    storagePath: w.storagePath || null,
    storageProvider: w.storageProvider || null,
    url: w.url || null,
    quiz: {
      questions: (w.quiz?.questions || []).map((q) => ({
        id: q.id,
        text: q.text,
        options: q.options,
        explanation: q.explanation,
        ...(isAdmin ? { correctIndex: q.correctIndex } : {}),
      })),
    },
  }));

  const modules = weeks.filter((w) => (w.category || 'module') === 'module');
  const liveWeeks = weeks.filter((w) => w.category === 'live');

  const supplementalWeek = {
    weekId: '__supplemental__',
    courseId: courseId,
    weekNumber: 'Supplemental',
    title: 'Supplemental Content',
    description: 'Course-wide supplemental assignments, recorded sessions, and calendar events.',
    visible: true,
    category: 'supplemental',
    assignments: supplementalContent?.assignments || [],
    liveRecordedSessions: supplementalContent?.liveRecordedSessions || [],
    calendarEvents: supplementalContent?.calendarEvents || [],
    resources: supplementalContent?.resources || [],
    docs: [],
    quiz: { questions: [] },
  };

  const allWeeks = [...weeks, supplementalWeek];

  return res(200, { weeks: allWeeks, modules, liveWeeks, supplementalContent });
}

function deriveUserPoolId(event) {
  if (process.env.USER_POOL_ID) return process.env.USER_POOL_ID;
  const issuer = event.requestContext?.authorizer?.claims?.iss;
  return issuer ? issuer.split('/').pop() : '';
}

function toIso(value) {
  if (!value) return null;
  try {
    const date = new Date(value);
    return isNaN(date.getTime()) ? null : date.toISOString();
  } catch {
    return null;
  }
}

function laterDate(a, b) {
  if (!a) return b || null;
  if (!b) return a || null;
  return a > b ? a : b;
}

function makeDisplayName(profile, userId, item) {
  if (item?.studentName && item.studentName.trim()) return item.studentName.trim();
  if (profile?.name && profile.name.trim()) return profile.name.trim();
  if (item?.studentEmail && item.studentEmail.trim()) return item.studentEmail.trim().split('@')[0];
  if (profile?.email && profile.email.trim()) return profile.email.trim().split('@')[0];
  if (userId && !userId.includes('-') && !userId.startsWith('student_')) return userId;
  return `Student ${String(userId || '').slice(-6) || 'Unknown'}`;
}

function makeLeaderboardEntry(userId, profile, currentUserId, item) {
  return {
    userId,
    displayName: makeDisplayName(profile, userId, item),
    email: profile?.email || item?.studentEmail || '',
    linkedinUrl: profile?.website || '',
    lecturePoints: 0,
    assignmentPoints: 0,
    completedLectures: 0,
    completedQuizzes: 0,
    assignmentsSubmitted: 0,
    score: 0,
    totalPoints: 0,
    lastActivity: null,
    isCurrentUser: userId === currentUserId,
  };
}

// Bolt Optimization⚡: In-memory TTL cache for Cognito User Pool scans to prevent hitting AWS rate limits.
let userProfilesCache = null;
let userProfilesCacheTimestamp = 0;
const USER_PROFILES_CACHE_TTL_MS = 15 * 60 * 1000; // 15 minutes TTL

async function listUsersBySub(userPoolId) {
  if (!userPoolId) return new Map();

  const now = Date.now();
  if (userProfilesCache && (now - userProfilesCacheTimestamp < USER_PROFILES_CACHE_TTL_MS)) {
    return userProfilesCache;
  }

  const usersBySub = new Map();
  let paginationToken;

  do {
    const result = await cognito.send(new ListUsersCommand({
      UserPoolId: userPoolId,
      PaginationToken: paginationToken,
    }));

    for (const user of (result.Users || [])) {
      const attrs = {};
      for (const attr of (user.Attributes || [])) attrs[attr.Name] = attr.Value;
      if (!attrs.sub) continue;
      usersBySub.set(attrs.sub, {
        name: attrs.name || '',
        email: attrs.email || '',
        website: attrs.website || '',
      });
    }

    paginationToken = result.PaginationToken;
  } while (paginationToken);

  userProfilesCache = usersBySub;
  userProfilesCacheTimestamp = now;
  return usersBySub;
}

function getOrCreateEntry(entries, userId, profiles, currentUserId, item) {
  let entry = entries.get(userId);
  if (!entry) {
    entry = makeLeaderboardEntry(userId, profiles.get(userId), currentUserId, item);
    entries.set(userId, entry);
  } else if (item?.studentName && entry.displayName.startsWith('Student ')) {
    entry.displayName = item.studentName;
  }
  return entry;
}

// Builds the complete leaderboard for a course.
// Returns an array of student ranking objects sorted by totalPoints descending.
async function buildLeaderboard(courseId, currentUserId, event) {
  const userPoolId = deriveUserPoolId(event);
  const isAiCourse = String(courseId).toLowerCase().includes('ai');
  const progressScanParams = { TableName: PROGRESS_TABLE };
  if (!isAiCourse) {
    progressScanParams.FilterExpression = 'courseId = :cid';
    progressScanParams.ExpressionAttributeValues = { ':cid': courseId };
  }

  const [weeksResult, progressResult, userProfiles, enrollmentsResult] = await Promise.all([
    ddb.send(new QueryCommand({
      TableName: COURSES_TABLE,
      KeyConditionExpression: 'pk = :pk AND begins_with(sk, :prefix)',
      ExpressionAttributeValues: {
        ':pk': `COURSE#${courseId}`,
        ':prefix': 'WEEK#',
      },
    })).catch((err) => {
      console.error('Course weeks query failed while building leaderboard:', err);
      return { Items: [] };
    }),
    ddb.send(new ScanCommand(progressScanParams)).catch((err) => {
      console.error('Progress scan failed while building leaderboard:', err);
      return { Items: [] };
    }),
    listUsersBySub(userPoolId).catch((err) => {
      console.error('Cognito user lookup failed while building leaderboard:', err);
      return new Map();
    }),
    ddb.send(new ScanCommand({
      TableName: ENROLLMENTS_TABLE,
      FilterExpression: 'courseId = :cid',
      ExpressionAttributeValues: { ':cid': courseId }
    })).catch((err) => {
      console.error('Enrollments scan failed while building leaderboard:', err);
      return { Items: [] };
    }),
  ]);

  const enrolledUserIds = new Set((enrollmentsResult.Items || []).map(item => item.enrollmentId));
  for (const item of (enrollmentsResult.Items || [])) {
    if (item.userId) enrolledUserIds.add(item.userId);
  }

  function hasSupplementalStudentContent(week) {
    return (week.assignments?.length || 0) > 0
      || (week.liveRecordedSessions?.length || 0) > 0
      || (week.calendarEvents?.length || 0) > 0;
  }
  const validWeeks = (weeksResult.Items || []).filter(
    (w) => w.visible === true || hasSupplementalStudentContent(w)
  );

  // Bolt Optimization⚡: Query targeted partition keys instead of a full table scan on ASSIGNMENTS_TABLE
  const assignmentQueries = validWeeks.map((w) =>
    ddb.send(new QueryCommand({
      TableName: ASSIGNMENTS_TABLE,
      KeyConditionExpression: 'pk = :pk',
      ExpressionAttributeValues: { ':pk': `COURSE#${courseId}#WEEK#${w.weekId}` },
    })).catch(() => ({ Items: [] }))
  );
  assignmentQueries.push(
    ddb.send(new QueryCommand({
      TableName: ASSIGNMENTS_TABLE,
      KeyConditionExpression: 'pk = :pk',
      ExpressionAttributeValues: { ':pk': `COURSE#${courseId}#SUPPLEMENTAL` },
    })).catch(() => ({ Items: [] }))
  );
  const assignmentResults = await Promise.all(assignmentQueries);
  const assignmentItems = assignmentResults.flatMap((r) => r.Items || []);

  const weekCategoryMap = new Map(
    validWeeks.map((week) => [
      week.weekId,
      week.category || (String(week.weekId || '').startsWith('rec') ? 'live' : 'module'),
    ]),
  );

  const leaderboardEntries = new Map();

  for (const item of (progressResult.Items || [])) {
    const itemUserId = item.userId || (item.pk ? item.pk.replace('USER#', '') : null);
    if (!itemUserId) continue;

    if (!isAiCourse) {
      if (item.courseId && item.courseId !== courseId) continue;
      if (enrolledUserIds.size > 0 && !enrolledUserIds.has(itemUserId) && !enrolledUserIds.has(item.userId)) continue;
    } else {
      // For AI courses, match any AI challenge or submission belonging to this course
      const isAiItem = item.courseId === courseId ||
        item.type === 'ai-gym-response' ||
        (item.sk && item.sk.startsWith('GYM#') && (item.day != null || (item.challengeTitle && item.challengeTitle.toLowerCase().includes('micro'))));
      if (!isAiItem) continue;
    }

    // PM Gym & AI Gym question completion gives score points
    if (item.sk && item.sk.startsWith('GYM#')) {
      const entry = getOrCreateEntry(leaderboardEntries, itemUserId, userProfiles, currentUserId, item);
      const points = typeof item.score === 'number' ? item.score : (isAiCourse ? 20 : 1);
      entry.score += points;
      entry.totalPoints += points;
      entry.lastActivity = laterDate(entry.lastActivity, toIso(item.submittedAt));
      continue;
    }

    const itemWeekId = item.weekId || (item.sk ? item.sk.split('#')[2] : null);
    if (!itemWeekId) continue;
    
    const weekCategory = weekCategoryMap.get(itemWeekId) || (String(itemWeekId).startsWith('rec') ? 'live' : 'module');
    const isLiveSession = weekCategory === 'live';

    const entry = getOrCreateEntry(leaderboardEntries, itemUserId, userProfiles, currentUserId);
    
    // A lecture is considered complete when the video is complete.
    const isComplete = !!item.videoComplete;
    if (isComplete) {
      entry.completedLectures += 1;
      // Live session recordings give 0 points; regular module lectures give 2 points
      if (!isLiveSession) {
        entry.score += 2;
        entry.totalPoints += 2;
      }
    }
    if (item.quizPassed) {
      entry.completedQuizzes += 1;
    }
    entry.lastActivity = laterDate(entry.lastActivity, toIso(item.videoCompletedAt || item.lastSeen));
  }

  const awardedAssignments = new Set();
  for (const item of assignmentItems) {
    const itemUserId = item.userId || (item.sk ? item.sk.split('#')[1] : null);
    const itemWeekId = item.weekId || (item.pk ? item.pk.split('#')[3] : null);
    if (!itemUserId || !itemWeekId) continue;
    if (!enrolledUserIds.has(itemUserId)) continue;

    const uniqueAssignmentId = item.assignmentId || itemWeekId;
    const assignmentKey = `${itemUserId}#${uniqueAssignmentId}`;
    if (awardedAssignments.has(assignmentKey)) continue;
    awardedAssignments.add(assignmentKey);

    const entry = getOrCreateEntry(leaderboardEntries, itemUserId, userProfiles, currentUserId);
    entry.assignmentPoints += 10;
    entry.assignmentsSubmitted += 1;
    entry.score += 10;
    entry.totalPoints += 10;
    entry.lastActivity = laterDate(entry.lastActivity, toIso(item.uploadedAt));
  }

  if (enrolledUserIds.has(currentUserId) && !leaderboardEntries.has(currentUserId)) {
    leaderboardEntries.set(
      currentUserId,
      makeLeaderboardEntry(currentUserId, userProfiles.get(currentUserId), currentUserId),
    );
  }

  // Bolt Optimization⚡: Fast string comparison operators replacing slow localeCompare in O(N log N) sort comparator
  return [...leaderboardEntries.values()]
    .sort((a, b) => {
      const scoreDiff = b.score - a.score;
      if (scoreDiff !== 0) return scoreDiff;

      const lecturesDiff = b.completedLectures - a.completedLectures;
      if (lecturesDiff !== 0) return lecturesDiff;

      const assignmentsDiff = b.assignmentsSubmitted - a.assignmentsSubmitted;
      if (assignmentsDiff !== 0) return assignmentsDiff;

      const actA = a.lastActivity || '';
      const actB = b.lastActivity || '';
      if (actB !== actA) return actB > actA ? 1 : -1;

      const nameA = a.displayName || '';
      const nameB = b.displayName || '';
      return nameA > nameB ? 1 : (nameA < nameB ? -1 : 0);
    })
    .map((entry, index) => ({
      ...entry,
      totalPoints: entry.score,
      score: entry.score,
      rank: index + 1,
    }));
}

function calculateGymStreak(gymProgress, clientDate) {
  const solvedDates = new Set(gymProgress.map(p => p.date));

  function getPrevGymDayUTC(dateStr) {
    const d = new Date(dateStr + 'T00:00:00Z');
    d.setUTCDate(d.getUTCDate() - 1);
    const yr = d.getUTCFullYear();
    const mo = String(d.getUTCMonth() + 1).padStart(2, '0');
    const dy = String(d.getUTCDate()).padStart(2, '0');
    return `${yr}-${mo}-${dy}`;
  }

  let streak = 0;
  let checkDate = clientDate;

  if (solvedDates.has(clientDate)) {
    streak++;
    checkDate = getPrevGymDayUTC(clientDate);
  } else {
    const prevGym = getPrevGymDayUTC(clientDate);
    if (solvedDates.has(prevGym)) {
      checkDate = prevGym;
    } else {
      return 0;
    }
  }

  while (solvedDates.has(checkDate)) {
    streak++;
    checkDate = getPrevGymDayUTC(checkDate);
  }

  return streak;
}

async function getProgressForCourse(courseId, userId, event) {
  if (!courseId) return res(400, { message: 'Missing courseId path parameter' });

  const includeLeaderboard = event.queryStringParameters?.includeLeaderboard === 'true';
  
  const [result, gymProgressResult, gymQuestionsResult] = await Promise.all([
    ddb.send(new QueryCommand({
      TableName: PROGRESS_TABLE,
      KeyConditionExpression: 'pk = :pk AND begins_with(sk, :prefix)',
      ExpressionAttributeValues: {
        ':pk': `USER#${userId}`,
        ':prefix': `PROGRESS#${courseId}#`,
      },
    })),
    ddb.send(new QueryCommand({
      TableName: PROGRESS_TABLE,
      KeyConditionExpression: 'pk = :pk AND begins_with(sk, :prefix)',
      ExpressionAttributeValues: {
        ':pk': `USER#${userId}`,
        ':prefix': `GYM#${courseId}#`,
      },
    })),
    ddb.send(new QueryCommand({
      TableName: COURSES_TABLE,
      KeyConditionExpression: 'pk = :pk AND begins_with(sk, :prefix)',
      ExpressionAttributeValues: {
        ':pk': `COURSE#${courseId}`,
        ':prefix': 'GYM#',
      },
    })),
  ]);

  const progress = (result.Items || []).map((item) => ({
    weekId: item.weekId,
    courseId: item.courseId,
    videoComplete: item.videoComplete || false,
    videoCompletedAt: item.videoCompletedAt || null,
    watchedSegments: item.watchedSegments ? [...item.watchedSegments] : [],
    duration: item.duration || 0,
    quizPassed: item.quizPassed || false,
    quizScore: item.quizScore ?? null,
    quizTotal: item.quizTotal ?? null,
    quizAttempts: item.quizAttempts || 0,
    lastSeen: item.lastSeen || null,
  }));

  const gymProgress = (gymProgressResult.Items || []).map((item) => ({
    date: item.date,
    type: item.type,
    answer: item.answer,
    score: item.score,
    submittedAt: item.submittedAt,
    challengeTitle: item.challengeTitle,
    day: item.day,
  }));

  const serverDateStr = new Date().toISOString().split('T')[0];
  const clientDate = event.queryStringParameters?.clientDate || serverDateStr;

  let rawGymItems = gymQuestionsResult.Items || [];
  const existingDates = new Set(rawGymItems.map((q) => q.date));
  const isAiCohort = String(courseId).toLowerCase().includes('ai');
  if (isAiCohort) {
    const aiItems = AI_GYM_CHALLENGES.filter((q) => !existingDates.has(q.date));
    rawGymItems = [...rawGymItems, ...aiItems];
  } else if (!existingDates.has(clientDate) || courseId === 'course-002' || rawGymItems.length === 0) {
    const batch2Items = BATCH_2_PRODUCT_DESIGN_CASE_STUDY.filter((q) => !existingDates.has(q.date));
    rawGymItems = [...rawGymItems, ...batch2Items];
  }

  const gymQuestions = rawGymItems.map((q) => {
    if (q.date >= clientDate) {
      const { correctIndex, correctAnswer, explanation, ...stripped } = q;
      return stripped;
    }
    return q;
  }).sort((a, b) => (a.date || '').localeCompare(b.date || ''));

  const gymStreak = calculateGymStreak(gymProgress, clientDate);

  if (!includeLeaderboard) {
    return res(200, { progress, gymProgress, gymQuestions, gymStreak });
  }

  try {
    const cacheKey = { pk: `COURSE#${courseId}`, sk: 'LEADERBOARD' };
    const cachedItemRes = await ddb.send(new GetCommand({
      TableName: COURSES_TABLE,
      Key: cacheKey,
    })).catch((err) => {
      console.error('Failed to get cached leaderboard:', err);
      return { Item: null };
    });

    const cachedItem = cachedItemRes.Item;
    const now = Date.now();
    const cacheDurationMs = 5 * 60 * 1000; // 5 minutes cache

    if (cachedItem && cachedItem.updatedAt && (now - cachedItem.updatedAt < cacheDurationMs) && Array.isArray(cachedItem.leaderboardData)) {
      // Personalize the cached leaderboard for the requesting user
      const personalizedLeaderboard = cachedItem.leaderboardData.map((entry) => ({
        ...entry,
        isCurrentUser: entry.userId === userId,
      }));
      return res(200, { progress, leaderboard: personalizedLeaderboard, gymProgress, gymQuestions, gymStreak });
    }

    // Cache miss or expired: build fresh leaderboard
    const leaderboard = await buildLeaderboard(courseId, userId, event);

    // Save to cache asynchronously (don't block the response)
    const cacheData = leaderboard.map(entry => ({
      ...entry,
      isCurrentUser: false,
    }));

    ddb.send(new UpdateCommand({
      TableName: COURSES_TABLE,
      Key: cacheKey,
      UpdateExpression: 'SET leaderboardData = :data, updatedAt = :now',
      ExpressionAttributeValues: {
        ':data': cacheData,
        ':now': now,
      },
    })).catch((err) => {
      console.error('Failed to update leaderboard cache:', err);
    });

    return res(200, { progress, leaderboard, gymProgress, gymQuestions, gymStreak });
  } catch (err) {
    console.error('Leaderboard build error:', err);
    return res(200, { progress, leaderboard: [], gymProgress, gymQuestions, gymStreak });
  }
}

async function recordHeartbeat(userId, body) {
  const { courseId, weekId, currentTime, duration, prevTime } = body;
  if (!courseId || !weekId || currentTime === undefined || !duration) {
    return res(400, { message: 'Missing required fields: courseId, weekId, currentTime, duration' });
  }

  // Parameter Validation
  if (typeof courseId !== 'string' || !/^[a-zA-Z0-9_-]{3,50}$/.test(courseId)) {
    return res(400, { message: 'Invalid courseId format.' });
  }
  if (typeof weekId !== 'string' || !/^[a-zA-Z0-9_-]{3,50}$/.test(weekId)) {
    return res(400, { message: 'Invalid weekId format.' });
  }
  if (typeof currentTime !== 'number' || currentTime < 0 || typeof duration !== 'number' || duration <= 0) {
    return res(400, { message: 'Invalid currentTime or duration.' });
  }
  if (prevTime !== undefined && (typeof prevTime !== 'number' || prevTime < 0)) {
    return res(400, { message: 'Invalid prevTime.' });
  }

  const startTime = typeof prevTime === 'number' ? prevTime : currentTime;
  const startSeg = Math.floor(startTime / HEARTBEAT_INTERVAL);
  const endSeg = Math.floor(currentTime / HEARTBEAT_INTERVAL);
  
  const segments = new Set();
  const minSeg = Math.min(startSeg, endSeg);
  const maxSeg = Math.max(startSeg, endSeg);
  for (let seg = minSeg; seg <= maxSeg; seg++) {
    segments.add(seg);
  }

  const totalSegments = Math.ceil(duration / HEARTBEAT_INTERVAL);

  const pk = `USER#${userId}`;
  const sk = `PROGRESS#${courseId}#${weekId}`;

  let result;
  try {
    result = await ddb.send(new UpdateCommand({
      TableName: PROGRESS_TABLE,
      Key: { pk, sk },
      UpdateExpression: `
        ADD watchedSegments :seg
        SET lastSeen  = :now,
            #dur      = :dur,
            userId    = :uid,
            courseId  = :cid,
            weekId    = :wid
      `,
      ExpressionAttributeNames: { '#dur': 'duration' },
      ExpressionAttributeValues: {
        ':seg': segments,
        ':now': new Date().toISOString(),
        ':dur': duration,
        ':uid': userId,
        ':cid': courseId,
        ':wid': weekId,
      },
      ReturnValues: 'ALL_NEW',
    }));
  } catch (err) {
    console.error('DynamoDB UpdateCommand error:', err);
    return res(500, { message: 'Failed to record progress' });
  }

  const item = result.Attributes;
  const watchedCount = item.watchedSegments ? item.watchedSegments.size : 0;
  const videoPct = Math.min(Math.round((watchedCount / totalSegments) * 100), 100);
  const alreadyComplete = item.videoComplete || false;
  const nowComplete = videoPct >= COMPLETION_THRESHOLD * 100;

  if (nowComplete && !alreadyComplete) {
    try {
      await ddb.send(new UpdateCommand({
        TableName: PROGRESS_TABLE,
        Key: { pk, sk },
        UpdateExpression: 'SET videoComplete = :t, videoCompletedAt = :now',
        ConditionExpression: 'attribute_not_exists(videoComplete) OR videoComplete = :f',
        ExpressionAttributeValues: {
          ':t':   true,
          ':f':   false,
          ':now': new Date().toISOString(),
        },
      }));
    } catch (condErr) {
      if (condErr.name !== 'ConditionalCheckFailedException') {
        console.error('videoComplete update error:', condErr);
      }
    }
  }

  return res(200, {
    videoPct,
    videoComplete: nowComplete || alreadyComplete,
    segmentsWatched: watchedCount,
    totalSegments,
  });
}

async function submitGymAttempt(userId, body, event) {
  const { courseId, answers } = body;
  if (!courseId || !answers || typeof answers !== 'object') {
    return res(400, { message: 'Missing required fields: courseId, answers' });
  }
  const date = Object.keys(answers)[0];
  const rawAnswer = answers[date];
  if (!date || rawAnswer === undefined) {
    return res(400, { message: 'Missing date or answer' });
  }

  // Get question to verify correct answer if it's a quiz
  let question;
  try {
    const qRes = await ddb.send(new GetCommand({
      TableName: COURSES_TABLE,
      Key: { pk: `COURSE#${courseId}`, sk: `GYM#${date}` },
    }));
    question = qRes.Item;
  } catch (err) {
    console.error('DynamoDB GetCommand error:', err);
  }
  if (!question) {
    question = BATCH_2_PRODUCT_DESIGN_CASE_STUDY.find((q) => q.date === date);
  }
  if (!question) {
    const aiChallenge = AI_GYM_CHALLENGES.find((c) => c.date === date || `day-${c.day}` === date || String(c.day) === date);
    if (aiChallenge) {
      question = {
        date: aiChallenge.date,
        day: aiChallenge.day,
        text: aiChallenge.title,
        title: aiChallenge.title,
        type: 'text',
        isAiGym: true,
      };
    }
  }
  if (!question) {
    if (String(courseId).toLowerCase().includes('ai')) {
      question = {
        date,
        text: `AI Gym Drill ${date}`,
        title: `AI Gym Drill ${date}`,
        type: 'text',
        isAiGym: true,
      };
    } else {
      return res(404, { message: 'Daily question not found' });
    }
  }

  const answerText = (typeof rawAnswer === 'object' && rawAnswer !== null)
    ? (rawAnswer.text || rawAnswer.answer || JSON.stringify(rawAnswer))
    : String(rawAnswer);

  const claimsName = event?.requestContext?.authorizer?.claims?.name;
  const claimsEmail = event?.requestContext?.authorizer?.claims?.email;
  const studentName = body.studentName || body.name || (typeof rawAnswer === 'object' ? rawAnswer.studentName : '') || claimsName || '';
  const studentEmail = body.studentEmail || body.email || (typeof rawAnswer === 'object' ? rawAnswer.studentEmail : '') || claimsEmail || '';

  let score = 0;
  if (typeof rawAnswer === 'object' && typeof rawAnswer.score === 'number') {
    score = rawAnswer.score;
  } else if (typeof body.score === 'number') {
    score = body.score;
  } else if (question.isAiGym || (typeof rawAnswer === 'object' && rawAnswer.type === 'ai-gym-response') || String(courseId).toLowerCase().includes('ai')) {
    score = 20;
  } else if (question.type === 'quiz') {
    score = (Number(answerText) === question.correctIndex) ? 1 : 0;
  } else {
    score = 1;
  }

  const effectiveUserId = (body.targetUserId || body.studentId || userId).replace(/^USER#/, '');
  const pk = `USER#${effectiveUserId}`;
  const sk = `GYM#${courseId}#${date}`;
  const challengeTitle = (typeof rawAnswer === 'object' && rawAnswer?.challengeTitle)
    ? rawAnswer.challengeTitle
    : (question.title || question.text || `Gym Drill ${date}`);

  await ddb.send(new UpdateCommand({
    TableName: PROGRESS_TABLE,
    Key: { pk, sk },
    UpdateExpression: 'SET courseId = :cid, #dt = :dt, #tp = :tp, answer = :ans, score = :score, submittedAt = :now, userId = :uid, challengeTitle = :title, #day = :day, studentName = :sname, studentEmail = :semail',
    ExpressionAttributeNames: {
      '#dt': 'date',
      '#tp': 'type',
      '#day': 'day',
    },
    ExpressionAttributeValues: {
      ':cid': courseId,
      ':dt': date,
      ':tp': question.isAiGym || String(courseId).toLowerCase().includes('ai') ? 'ai-gym-response' : question.type,
      ':ans': answerText,
      ':score': score,
      ':now': new Date().toISOString(),
      ':uid': effectiveUserId,
      ':title': challengeTitle,
      ':day': question.day || (typeof rawAnswer === 'object' ? rawAnswer.day : null) || null,
      ':sname': studentName || effectiveUserId,
      ':semail': studentEmail || '',
    },
  }));

  return res(200, {
    message: 'Answer submitted successfully',
    score,
    type: question.type,
  });
}

async function submitQuizAttempt(userId, body, event) {
  const { courseId, weekId, answers } = body;
  if (!courseId || !weekId || !answers || typeof answers !== 'object') {
    return res(400, { message: 'Missing required fields: courseId, weekId, answers' });
  }

  // Parameter Validation
  if (typeof courseId !== 'string' || !/^[a-zA-Z0-9_-]{3,50}$/.test(courseId)) {
    return res(400, { message: 'Invalid courseId format.' });
  }
  if (typeof weekId !== 'string' || (!/^[a-zA-Z0-9_-]{3,50}$/.test(weekId) && weekId !== 'gym')) {
    return res(400, { message: 'Invalid weekId format.' });
  }

  if (weekId === 'gym') {
    return await submitGymAttempt(userId, body, event);
  }

  let weekItem;
  try {
    const r = await ddb.send(new GetCommand({
      TableName: COURSES_TABLE,
      Key: { pk: `COURSE#${courseId}`, sk: `WEEK#${weekId}` },
    }));
    weekItem = r.Item;
  } catch (err) {
    console.error('getCourseWeek error:', err);
    return res(500, { message: 'Failed to load quiz' });
  }

  if (!weekItem) return res(404, { message: 'Week not found' });

  const questions = weekItem.quiz?.questions || [];
  if (questions.length === 0) {
    return res(400, { message: 'This week has no quiz questions.' });
  }

  let correct = 0;
  const correctAnswers = {};
  for (const q of questions) {
    correctAnswers[q.id] = q.correctIndex;
    if (answers[q.id] === q.correctIndex) correct++;
  }

  const total = questions.length;
  const pct = Math.round((correct / total) * 100);
  const passed = pct >= PASSING_PCT;

  const progressPk = `USER#${userId}`;
  const progressSk = `PROGRESS#${courseId}#${weekId}`;

  try {
    await ddb.send(new UpdateCommand({
      TableName: PROGRESS_TABLE,
      Key: { pk: progressPk, sk: progressSk },
      UpdateExpression: `
        SET quizPassed    = :passed,
            quizScore     = :score,
            quizTotal     = :total,
            lastSeen      = :now
        ADD quizAttempts  :one
      `,
      ExpressionAttributeValues: {
        ':passed': passed,
        ':score': correct,
        ':total': total,
        ':now': new Date().toISOString(),
        ':one': 1,
      },
      ReturnValues: 'UPDATED_NEW',
    }));
  } catch (err) {
    console.error('saveQuizResult error:', err);
  }

  return res(200, { passed, score: correct, total, pct, correctAnswers });
}

async function getQAQuestions(courseId, weekId) {
  if (!courseId || !weekId) {
    return res(400, { message: 'Missing courseId or weekId' });
  }

  try {
    const result = await ddb.send(new QueryCommand({
      TableName: COURSES_TABLE,
      KeyConditionExpression: 'pk = :pk AND begins_with(sk, :prefix)',
      ExpressionAttributeValues: {
        ':pk': `COURSE#${courseId}`,
        ':prefix': `QA#${weekId}#`,
      },
    }));

    const questions = (result.Items || []).map((item) => ({
      id: item.id,
      author: item.author,
      text: item.text,
      date: item.date || 'Just now',
      createdAt: item.createdAt,
    })).sort((a, b) => b.id - a.id); // Latest first

    return res(200, { questions });
  } catch (err) {
    console.error('getQAQuestions error:', err);
    return res(500, { message: 'Failed to fetch questions' });
  }
}

async function postQAQuestion(courseId, weekId, userId, body, event) {
  if (!courseId || !weekId) {
    return res(400, { message: 'Missing courseId or weekId' });
  }
  if (!body || typeof body.text !== 'string' || !body.text.trim()) {
    return res(400, { message: 'Question text must be a non-empty string.' });
  }

  // Parameter Validation
  if (!/^[a-zA-Z0-9_-]{3,50}$/.test(courseId)) {
    return res(400, { message: 'Invalid courseId format.' });
  }
  if (!/^[a-zA-Z0-9_-]{3,50}$/.test(weekId)) {
    return res(400, { message: 'Invalid weekId format.' });
  }

  const claimsName = event.requestContext?.authorizer?.claims?.name;
  const claimsEmail = event.requestContext?.authorizer?.claims?.email;
  const authorName = claimsName || claimsEmail || `Student ${String(userId || '').slice(-6) || 'Unknown'}`;

  const questionId = Date.now();
  const nowStr = new Date().toISOString();
  const dateStr = 'Just now';

  const item = {
    pk: `COURSE#${courseId}`,
    sk: `QA#${weekId}#${questionId}`,
    id: questionId,
    courseId,
    weekId,
    userId,
    author: authorName,
    text: body.text.trim(),
    date: dateStr,
    createdAt: nowStr,
    type: 'qa',
  };

  try {
    await ddb.send(new UpdateCommand({
      TableName: COURSES_TABLE,
      Key: { pk: item.pk, sk: item.sk },
      UpdateExpression: 'SET id = :id, courseId = :courseId, weekId = :weekId, userId = :userId, author = :author, #txt = :text, #dt = :date, createdAt = :createdAt, #tp = :type',
      ExpressionAttributeNames: {
        '#txt': 'text',
        '#dt': 'date',
        '#tp': 'type',
      },
      ExpressionAttributeValues: {
        ':id': item.id,
        ':courseId': item.courseId,
        ':weekId': item.weekId,
        ':userId': item.userId,
        ':author': item.author,
        ':text': item.text,
        ':date': item.date,
        ':createdAt': item.createdAt,
        ':type': item.type,
      },
    }));

    return res(200, {
      question: {
        id: item.id,
        author: item.author,
        text: item.text,
        date: item.date,
        createdAt: item.createdAt,
      },
    });
  } catch (err) {
    console.error('postQAQuestion error:', err);
    return res(500, { message: 'Failed to post question' });
  }
}

// ── Peer-to-Peer Sessions ──────────────────────────────────────────────────

async function getUserProfile(userId, event) {
  const claimsName = event?.requestContext?.authorizer?.claims?.name;
  const claimsEmail = event?.requestContext?.authorizer?.claims?.email;
  if (claimsName && claimsEmail) {
    return { name: claimsName, email: claimsEmail };
  }
  const userPoolId = process.env.USER_POOL_ID || 'eu-north-1_jnwEn55p2';
  try {
    const usersMap = await listUsersBySub(userPoolId);
    const profile = usersMap.get(userId);
    return {
      name: claimsName || profile?.name || `Student ${String(userId || '').slice(-6) || 'Unknown'}`,
      email: claimsEmail || profile?.email || '',
    };
  } catch (err) {
    console.error('Error in getUserProfile:', err);
    return {
      name: claimsName || `Student ${String(userId || '').slice(-6) || 'Unknown'}`,
      email: claimsEmail || '',
    };
  }
}

async function getCourseName(courseId) {
  if (COURSE_NAME_OVERRIDES[courseId]) return COURSE_NAME_OVERRIDES[courseId];
  try {
    const res = await ddb.send(new GetCommand({
      TableName: COURSES_TABLE,
      Key: { pk: `COURSE#${courseId}`, sk: 'METADATA' },
    }));
    return res.Item?.title || res.Item?.name || courseId;
  } catch {
    return courseId;
  }
}

async function sendPeerSessionConfirmationEmails({
  hostName,
  hostEmail,
  peerName,
  peerEmail,
  courseName,
  topic,
  scheduledStartTime,
  scheduledEndTime,
  meetingUrl,
}) {
  if (!FROM_EMAIL) {
    console.log('Skipping email notification: FROM_EMAIL is not configured');
    return;
  }

  const formattedStart = new Date(scheduledStartTime).toLocaleString('en-US', {
    dateStyle: 'full',
    timeStyle: 'short',
    timeZone: 'UTC',
  }) + ' UTC';

  const safeTopic = topic || 'General Study & Practice';
  const safeMeetingUrl = meetingUrl || 'To be shared by host';

  const hostSubject = `Peer Study Session Confirmed: ${peerName} joined your slot!`;
  const hostHtml = `
    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 560px; margin: 0 auto; padding: 24px; border: 2px solid #000; border-radius: 8px; background: #fff;">
      <h2 style="font-size: 20px; font-weight: 800; margin-top: 0; color: #111;">Peer Study Session Confirmed 🎉</h2>
      <p style="font-size: 15px; color: #333; line-height: 1.5;">
        Hi <strong>${hostName}</strong>,
      </p>
      <p style="font-size: 15px; color: #333; line-height: 1.5;">
        Great news! <strong>${peerName}</strong>${peerEmail ? ` (${peerEmail})` : ''} has booked your study slot for <strong>${courseName}</strong>.
      </p>
      <div style="background: #f4f4f5; border: 1px solid #e4e4e7; border-radius: 6px; padding: 16px; margin: 20px 0;">
        <p style="margin: 0 0 8px 0; font-size: 14px;"><strong>Topic:</strong> ${safeTopic}</p>
        <p style="margin: 0 0 8px 0; font-size: 14px;"><strong>Date & Time:</strong> ${formattedStart}</p>
        <p style="margin: 0; font-size: 14px;"><strong>Meeting Link:</strong> <a href="${safeMeetingUrl}" target="_blank" style="color: #2563eb; font-weight: 600;">${safeMeetingUrl}</a></p>
      </div>
      <p style="font-size: 14px; color: #666; line-height: 1.5;">
        Please be on time and bring any questions or discussion points. Happy learning!
      </p>
      <hr style="border: none; border-top: 1px solid #e4e4e7; margin: 24px 0;" />
      <p style="font-size: 12px; color: #888; margin: 0;">StepSmart LMS — Peer-to-Peer Learning Network</p>
    </div>
  `;

  const peerSubject = `Peer Study Session Confirmed: You're matched with ${hostName}!`;
  const peerHtml = `
    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 560px; margin: 0 auto; padding: 24px; border: 2px solid #000; border-radius: 8px; background: #fff;">
      <h2 style="font-size: 20px; font-weight: 800; margin-top: 0; color: #111;">You're Booked for a Peer Session 🚀</h2>
      <p style="font-size: 15px; color: #333; line-height: 1.5;">
        Hi <strong>${peerName}</strong>,
      </p>
      <p style="font-size: 15px; color: #333; line-height: 1.5;">
        You have successfully connected with <strong>${hostName}</strong>${hostEmail ? ` (${hostEmail})` : ''} for <strong>${courseName}</strong>.
      </p>
      <div style="background: #f4f4f5; border: 1px solid #e4e4e7; border-radius: 6px; padding: 16px; margin: 20px 0;">
        <p style="margin: 0 0 8px 0; font-size: 14px;"><strong>Topic:</strong> ${safeTopic}</p>
        <p style="margin: 0 0 8px 0; font-size: 14px;"><strong>Date & Time:</strong> ${formattedStart}</p>
        <p style="margin: 0; font-size: 14px;"><strong>Meeting Link:</strong> <a href="${safeMeetingUrl}" target="_blank" style="color: #2563eb; font-weight: 600;">${safeMeetingUrl}</a></p>
      </div>
      <p style="font-size: 14px; color: #666; line-height: 1.5;">
        Reach out to each other if you need to coordinate anything prior to the call.
      </p>
      <hr style="border: none; border-top: 1px solid #e4e4e7; margin: 24px 0;" />
      <p style="font-size: 12px; color: #888; margin: 0;">StepSmart LMS — Peer-to-Peer Learning Network</p>
    </div>
  `;

  const tasks = [];
  if (hostEmail) {
    tasks.push(
      sendEmailNotification({
        to: hostEmail,
        subject: hostSubject,
        html: hostHtml,
      })
    );
  }
  if (peerEmail) {
    tasks.push(
      sendEmailNotification({
        to: peerEmail,
        subject: peerSubject,
        html: peerHtml,
      })
    );
  }

  // Also send an administrative booking record to admin@stepsmart.net
  const adminTarget = FROM_EMAIL || GMAIL_USER || 'admin@stepsmart.net';
  if (adminTarget) {
    const adminSubject = `[Booking Alert] ${peerName} booked study session with ${hostName}`;
    const adminHtml = `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 560px; margin: 0 auto; padding: 24px; border: 1px solid #e4e4e7; border-radius: 8px;">
        <h2 style="color: #0f172a; margin-top: 0;">New Peer Study Session Booked!</h2>
        <p><strong>Host:</strong> ${hostName} (${hostEmail || 'N/A'})</p>
        <p><strong>Peer:</strong> ${peerName} (${peerEmail || 'N/A'})</p>
        <p><strong>Cohort / Course:</strong> ${courseName}</p>
        <p><strong>Topic:</strong> ${safeTopic}</p>
        <p><strong>Scheduled Time:</strong> ${formattedStart}</p>
        <p><strong>Meeting Room:</strong> <a href="${safeMeetingUrl}">${safeMeetingUrl}</a></p>
      </div>
    `;
    tasks.push(
      sendEmailNotification({
        to: adminTarget,
        subject: adminSubject,
        html: adminHtml,
      })
    );
  }

  await Promise.allSettled(tasks);
}

// Global across all batches: returns all open slots in the academy
async function listOpenPeerSessions(courseId, userId) {
  const nowIso = new Date().toISOString();
  try {
    const result = await ddb.send(new ScanCommand({
      TableName: PEER_SESSIONS_TABLE,
      FilterExpression: '#status = :open AND scheduledStartTime >= :now',
      ExpressionAttributeNames: { '#status': 'status' },
      ExpressionAttributeValues: {
        ':open': 'OPEN',
        ':now': nowIso,
      },
    }));

    const items = (result.Items || [])
      .map((item) => ({
        sessionId: item.sessionId,
        courseId: item.courseId,
        courseName: item.courseName || item.batchName || '',
        hostUserId: item.hostUserId,
        hostName: item.hostName,
        scheduledStartTime: item.scheduledStartTime,
        scheduledEndTime: item.scheduledEndTime,
        topic: item.topic || 'General Discussion',
        notes: item.notes || '',
        meetingUrl: item.meetingUrl,
        status: item.status,
        isMySlot: item.hostUserId === userId,
        createdAt: item.createdAt,
      }));

    items.sort((a, b) => (a.scheduledStartTime || '').localeCompare(b.scheduledStartTime || ''));

    return res(200, { sessions: items });
  } catch (err) {
    console.error('listOpenPeerSessions error:', err);
    return res(500, { message: 'Failed to list open peer sessions' });
  }
}

// Global across all batches: returns all of the user's scheduled sessions regardless of active course
async function listMyPeerSessions(courseId, userId) {
  try {
    const [hostRes, peerRes] = await Promise.all([
      ddb.send(new QueryCommand({
        TableName: PEER_SESSIONS_TABLE,
        IndexName: 'HostSlotsIndex',
        KeyConditionExpression: 'hostUserId = :uid',
        ExpressionAttributeValues: { ':uid': userId },
      })).catch((err) => {
        console.error('HostSlotsIndex query error:', err);
        return { Items: [] };
      }),
      ddb.send(new QueryCommand({
        TableName: PEER_SESSIONS_TABLE,
        IndexName: 'PeerSlotsIndex',
        KeyConditionExpression: 'peerUserId = :uid',
        ExpressionAttributeValues: { ':uid': userId },
      })).catch((err) => {
        console.error('PeerSlotsIndex query error:', err);
        return { Items: [] };
      }),
    ]);

    let offered = hostRes.Items || [];
    let booked = peerRes.Items || [];

    offered.sort((a, b) => (a.scheduledStartTime || '').localeCompare(b.scheduledStartTime || ''));
    booked.sort((a, b) => (a.scheduledStartTime || '').localeCompare(b.scheduledStartTime || ''));

    return res(200, { offered, booked });
  } catch (err) {
    console.error('listMyPeerSessions error:', err);
    return res(500, { message: 'Failed to fetch your peer sessions' });
  }
}

async function createPeerSession(courseId, userId, body, event) {
  const { scheduledStartTime, scheduledEndTime, topic, notes, customMeetingUrl } = body || {};

  if (!scheduledStartTime) {
    return res(400, { message: 'Missing scheduledStartTime' });
  }

  const startTimeDate = new Date(scheduledStartTime);
  if (isNaN(startTimeDate.getTime())) {
    return res(400, { message: 'Invalid scheduledStartTime format' });
  }

  if (startTimeDate.getTime() < Date.now() - 60000) {
    return res(400, { message: 'Slot must be scheduled in the future' });
  }

  let endTimeStr = scheduledEndTime;
  if (!endTimeStr) {
    const end = new Date(startTimeDate.getTime() + 45 * 60 * 1000);
    endTimeStr = end.toISOString();
  }

  const userProfile = await getUserProfile(userId, event);
  const sessionId = `p2p_${crypto.randomUUID().replace(/-/g, '')}`;
  const meetingUrl = customMeetingUrl && typeof customMeetingUrl === 'string' && customMeetingUrl.startsWith('http')
    ? customMeetingUrl.trim()
    : `https://meet.jit.si/stepsmart-p2p-${sessionId.slice(-10)}`;

  const ttl = Math.floor(startTimeDate.getTime() / 1000) + (30 * 86400);
  const courseName = await getCourseName(courseId);

  const item = {
    sessionId,
    courseId,
    courseName,
    batchName: courseName,
    status: 'OPEN',
    hostUserId: userId,
    hostName: userProfile.name,
    hostEmail: userProfile.email,
    topic: (topic && typeof topic === 'string') ? topic.slice(0, 150).trim() : 'General Discussion & Study',
    notes: (notes && typeof notes === 'string') ? notes.slice(0, 500).trim() : '',
    scheduledStartTime: startTimeDate.toISOString(),
    scheduledEndTime: endTimeStr,
    meetingUrl,
    createdAt: new Date().toISOString(),
    ttl,
  };

  try {
    await ddb.send(new PutCommand({
      TableName: PEER_SESSIONS_TABLE,
      Item: item,
    }));

    return res(201, { session: item, message: 'Peer slot created successfully' });
  } catch (err) {
    console.error('createPeerSession error:', err);
    return res(500, { message: 'Failed to create peer slot' });
  }
}

async function bookPeerSession(courseId, sessionId, userId, event) {
  if (!sessionId) return res(400, { message: 'Missing sessionId' });

  let session;
  try {
    const sRes = await ddb.send(new GetCommand({
      TableName: PEER_SESSIONS_TABLE,
      Key: { sessionId },
    }));
    session = sRes.Item;
  } catch (err) {
    console.error('Error fetching session:', err);
    return res(500, { message: 'Error checking session availability' });
  }

  if (!session) {
    return res(404, { message: 'Study slot not found' });
  }

  if (session.hostUserId === userId) {
    return res(400, { message: 'You cannot connect to your own slot' });
  }

  if (session.status !== 'OPEN') {
    return res(409, { message: 'This slot has already been booked by another student' });
  }

  const userProfile = await getUserProfile(userId, event);
  const nowIso = new Date().toISOString();

  try {
    const updateRes = await ddb.send(new UpdateCommand({
      TableName: PEER_SESSIONS_TABLE,
      Key: { sessionId },
      UpdateExpression: 'SET #status = :booked, peerUserId = :pUid, peerName = :pName, peerEmail = :pEmail, bookedAt = :now',
      ConditionExpression: 'attribute_exists(sessionId) AND #status = :open AND hostUserId <> :pUid',
      ExpressionAttributeNames: { '#status': 'status' },
      ExpressionAttributeValues: {
        ':booked': 'BOOKED',
        ':open': 'OPEN',
        ':pUid': userId,
        ':pName': userProfile.name,
        ':pEmail': userProfile.email,
        ':now': nowIso,
      },
      ReturnValues: 'ALL_NEW',
    }));

    const updatedSession = updateRes.Attributes;
    const sessionCourseName = updatedSession.courseName || updatedSession.batchName || await getCourseName(courseId);

    await sendPeerSessionConfirmationEmails({
      hostName: updatedSession.hostName,
      hostEmail: updatedSession.hostEmail,
      peerName: updatedSession.peerName,
      peerEmail: updatedSession.peerEmail,
      courseName: sessionCourseName,
      topic: updatedSession.topic,
      scheduledStartTime: updatedSession.scheduledStartTime,
      scheduledEndTime: updatedSession.scheduledEndTime,
      meetingUrl: updatedSession.meetingUrl,
    }).catch((mailErr) => console.error('Error sending confirmation emails:', mailErr));

    return res(200, {
      session: updatedSession,
      message: 'Successfully connected! Confirmation emails sent to both participants.',
    });
  } catch (err) {
    if (err.name === 'ConditionalCheckFailedException') {
      return res(409, { message: 'This slot was just booked by another student' });
    }
    console.error('bookPeerSession error:', err);
    return res(500, { message: 'Failed to book peer session' });
  }
}

async function cancelPeerSession(courseId, sessionId, userId) {
  if (!sessionId) return res(400, { message: 'Missing sessionId' });

  let session;
  try {
    const sRes = await ddb.send(new GetCommand({
      TableName: PEER_SESSIONS_TABLE,
      Key: { sessionId },
    }));
    session = sRes.Item;
  } catch (err) {
    return res(500, { message: 'Error retrieving session' });
  }

  if (!session) return res(404, { message: 'Session not found' });

  const isHost = session.hostUserId === userId;
  const isPeer = session.peerUserId === userId;

  if (!isHost && !isPeer) {
    return res(403, { message: 'You are not authorized to cancel this session' });
  }

  try {
    if (isHost) {
      if (session.status === 'OPEN') {
        await ddb.send(new DeleteCommand({
          TableName: PEER_SESSIONS_TABLE,
          Key: { sessionId },
        }));
        return res(200, { message: 'Open slot deleted successfully' });
      } else {
        await ddb.send(new UpdateCommand({
          TableName: PEER_SESSIONS_TABLE,
          Key: { sessionId },
          UpdateExpression: 'SET #status = :cancelled, cancelledAt = :now, cancelledBy = :by',
          ExpressionAttributeNames: { '#status': 'status' },
          ExpressionAttributeValues: {
            ':cancelled': 'CANCELLED',
            ':now': new Date().toISOString(),
            ':by': 'host',
          },
        }));
        return res(200, { message: 'Booked session cancelled' });
      }
    } else {
      await ddb.send(new UpdateCommand({
        TableName: PEER_SESSIONS_TABLE,
        Key: { sessionId },
        UpdateExpression: 'SET #status = :open REMOVE peerUserId, peerName, peerEmail, bookedAt',
        ExpressionAttributeNames: { '#status': 'status' },
        ExpressionAttributeValues: { ':open': 'OPEN' },
      }));
      return res(200, { message: 'You left the session. Slot is now reopened for other students.' });
    }
  } catch (err) {
    console.error('cancelPeerSession error:', err);
    return res(500, { message: 'Failed to cancel session' });
  }
}

exports.handler = async (event) => {
  currentOrigin = event?.headers?.origin || event?.headers?.Origin || FRONTEND_URL;
  if (event.httpMethod === 'OPTIONS') return res(200, {});

  const userId = event.requestContext?.authorizer?.claims?.sub;
  if (!userId) return res(401, { message: 'Unauthorized' });

  const method = event.httpMethod;
  const resource = normalizeResource(event.resource || '');
  const params = event.pathParameters || {};
  const courseId = params.courseId || params.courseID;
  const sessionId = params.sessionId || params.sessionID;

  let body = {};
  try {
    if (event.body) body = JSON.parse(event.body);
  } catch {
    return res(400, { message: 'Invalid JSON body' });
  }

  // Enrollment Verification Guard
  const targetCourseId = courseId || body.courseId || body.courseID;
  if (targetCourseId && resource !== '/courses/my') {
    const isPeerSessionRoute = resource.includes('/peer-sessions');
    const enrolled = await checkEnrollment(userId, targetCourseId, event);
    if (!enrolled && !isPeerSessionRoute) {
      return res(403, { message: 'Forbidden: you are not enrolled in this course.' });
    }
  }

  try {
    if (method === 'GET' && resource === '/courses/my') return await listMyCourses(userId, event);
    if (method === 'GET' && resource === '/courses/{courseId}/weeks') return await listCourseWeeks(courseId, event);
    if (method === 'GET' && resource === '/courses/{courseId}/weeks/{weekId}/qa') return await getQAQuestions(courseId, params.weekId);
    if (method === 'POST' && resource === '/courses/{courseId}/weeks/{weekId}/qa') return await postQAQuestion(courseId, params.weekId, userId, body, event);
    if (method === 'GET' && resource === '/progress/{courseId}') return await getProgressForCourse(courseId, userId, event);
    if (method === 'POST' && resource === '/progress/heartbeat') return await recordHeartbeat(userId, body);
    if (method === 'POST' && resource === '/quiz/submit') return await submitQuizAttempt(userId, body, event);

    // Peer-to-Peer Session routes
    if (method === 'GET' && resource === '/courses/{courseId}/peer-sessions') return await listOpenPeerSessions(courseId, userId);
    if (method === 'POST' && resource === '/courses/{courseId}/peer-sessions') return await createPeerSession(courseId, userId, body, event);
    if (method === 'GET' && resource === '/courses/{courseId}/peer-sessions/my') return await listMyPeerSessions(courseId, userId);
    if (method === 'POST' && resource === '/courses/{courseId}/peer-sessions/{sessionId}/book') return await bookPeerSession(courseId, sessionId, userId, event);
    if (method === 'POST' && resource === '/courses/{courseId}/peer-sessions/{sessionId}/cancel') return await cancelPeerSession(courseId, sessionId, userId);

    return res(404, { message: `No handler for ${method} ${resource}` });
  } catch (err) {
    console.error(`Student handler error [${method} ${resource}]:`, err);
    return res(500, { message: err.message || 'Internal server error' });
  }
};

